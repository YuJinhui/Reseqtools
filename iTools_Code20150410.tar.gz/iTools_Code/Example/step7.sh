#!/bin/sh
#$ -S /bin/sh
#Version1.0	hewm@genomics.org.cn	2012-05-29
echo Start Time : 
date
../bin/iTools	Gfftools	VarType	-Ref	/ifs5/PC_PA_AP/USER/heweiming/soy31/ref/soybean.merge.fa	-Gff	/ifs5/PC_PA_AP/USER/heweiming/soy31/ref/soybean.fa.gff3.gz	-SNP	ALL.add_ref	-Format	add_ref	-MAllele	>	stat	
echo End Time : 
date
