//header file: main.h
#ifndef _MAIN_SVH_
#define _MAIN_SVH_


struct global_param
{
	VString		vstr;
	string		chr;
};

#ifdef __cplusplus
extern "C" {
#endif

	int main_len2chrome(int argc, char* argv[], void* pVoid);
	int	main_align2pe(int argc, char* argv[], void* pVoid);
	int	main_Bamalign2pe(int argc, char* argv[], void* pVoid);
	int	main_findsv(int argc, char* argv[], void* pVoid);
	int main_filtersv(int argc, char* argv[], void* pVoid);
	int main_simplify(int argc, char* argv[]);

#ifdef __cplusplus
}
#endif

#endif //_MAIN_H_
