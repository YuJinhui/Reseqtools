#ifndef _FINDFILE_H_
#define _FINDFILE_H_
#include "include.h"
#include "source.h"

enum Findtype{FN = 0, DN, DF, ALL};//FN=>File in current directory. DN=>Directory in current directory. DF=>File in children directory of current directory. ALL=>All file in current directory.

class CFindfile
{
public:
	CFindfile()
	{m_pdir = NULL;}
	CFindfile(const char* pdir, Findtype ft = FN, const char* pft = NULL);
	~CFindfile()
	{Safe_DeleteVec(m_pdir);}

private:
//Attribute
	char*		m_pdir;

	typedef vector<string>	vstring;
	vstring		m_vstrfilename;

private:
//private functions
	void 		Findfile(Findtype ft = FN, const char* pft = NULL);
	void 		Readchilddir(const char* pdn, const char* pft = NULL);
public:
//Functions
	int 		GetCount(){return (int)m_vstrfilename.size();}//File count.
	char*		GetFilename(int nIndex){return (nIndex>=0 || nIndex<GetCount())?const_cast<char*>(m_vstrfilename[nIndex].c_str()):NULL;}
	
};

CFindfile::CFindfile(const char* pdir, Findtype ft /*= FN*/, const char* pft /*= NULL*/)
{//pft indicate extanded name of the file to be find. Default to find all types files.
	m_pdir = NULL;
	int nlen = strlen(pdir);
	if(nlen == 0)
	{
		cout<<"No such directory!"<<endl;
		return;
	}

	m_pdir = new char[nlen+1];
	memcpy(m_pdir, pdir, nlen+1);
	
	Findfile(ft, pft);
}

void CFindfile::Findfile(Findtype ft, const char* pft)
{
	string		strdir(m_pdir);
	strdir.insert(strdir.length(), "/");
	
	DIR *dir = opendir(strdir.c_str());
	if(dir == NULL)
	{
		cout<<"Open directory error! No such directory!"<<endl;
		return;
	}
	dirent *dt = NULL;
	
	string 	str;	
	char 	temp[256];	
	
	while((dt = readdir(dir)) != NULL)
	{	
		str = dt->d_name;
		strcat(temp, strdir.c_str());
		strcat(temp, dt->d_name);		
		
		if(dt->d_name[0] == '.' || strcmp(dt->d_name, "..") == 0)
		{
			temp[0] = '\0';
			continue;
		}
		if(ft == FN)
		{	
			if(dt->d_type != 8)
			{
				temp[0] = '\0';
				continue;
			}
			if(str.find(pft)+strlen(pft) == str.length())
			{
				m_vstrfilename.push_back(string(temp));//Just find file in current directory.
			}
		}
		else if(ft == DN)
		{
			if(dt->d_type != 8)
				m_vstrfilename.push_back(string(temp));// Just find directory
		}
		else if(ft == DF)
		{
			if(dt->d_type != 8)
			{
				Readchilddir(temp, pft);//Just find file in the child directory of the current directory
			}
		}
		else
		{
			if(dt->d_type == 8)
				m_vstrfilename.push_back(string(temp));
			else
			{
				Readchilddir(temp, pft);
			}
		}
		
		temp[0] = '\0'; 
	}
	sort(m_vstrfilename.begin(), m_vstrfilename.end());
	closedir(dir);
}

void CFindfile::Readchilddir(const char* pdn, const char* pft)
{
	DIR *dir = opendir(pdn);
	if(dir == NULL)
	{
		cout<<"Open directory error! No such directory!"<<endl;
		return;
	}
	dirent *dt = NULL;
	
	string  str;
	char 	temp[256];
	
	while((dt = readdir(dir)) != NULL)
	{
		strcat(temp, pdn);
		strcat(temp, "/");
		strcat(temp, dt->d_name);
		str = dt->d_name;
		if(dt->d_name[0] == '.' || strcmp(dt->d_name, "..") == 0)
		{
			temp[0] = '\0';
			continue;
		}
		if(dt->d_type != 8)
		{
			temp[0] = '\0';
			continue;
		}
		if(pft == NULL)
			m_vstrfilename.push_back(string(temp));
		else if(str.find(pft)+strlen(pft) == str.length())
			m_vstrfilename.push_back(string(temp));
		temp[0] = '\0';
	}
	closedir(dir);
}

#endif

