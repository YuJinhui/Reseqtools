#!/bin/sh
#$ -S /bin/sh
#Version1.0	hewm@genomics.org.cn	2015-04-11
echo Start Time : 
date
g++	-lm	-luuid	-lgd	-lpng	-ljpeg	Var_BamSV_main.cpp	-lgzstream	-lz	-L	../../include/gzstream	-lbam	-L	../../include/sam/	-lpthread	-lboost_thread	
echo End Time : 
date
