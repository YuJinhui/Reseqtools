/** @file parse.h
 * This is the header file of the 'parse' module 
 */

#ifndef _PARSE_H_
#define _PARSE_H_

#include <iostream>
#include <vector>
#include <string>
#include <map>

#include <fstream>
#include <sstream>
#include <exception>
#include <ctime>
#include "../../include/gzstream/gzstream.h"
#include "parse.h"


extern int mismatch_offset;
long indel_reads_cnt = 0;       ///< count the reads with indels in soap result
long indel_discard_cnt = 0;     ///< count the reads with indes which are discarded
#define KEY_MAX_LEN  1024 

using namespace std;
/**
 *The class is used for storing the information of indels
 */
class indel_info
{
	public:
		string id;                      ///< get it from the soap result, useless
		string type;                    ///< insertion or deletion
        char fr;                        ///< strand
		string chr;                     ///< chromosome name
		unsigned long pos;  			///< position in chrom,key value
		size_t size;                    ///< indel size
		string minfo;                   ///< mismatch information 
		string indel_str;               ///< concrete indel string
		string pair_type;               ///< homozygosis or heterozygosis
		short qual_sco;                 ///< average quality score
		float pos_sco;                  ///< average position score
		size_t read_len;                ///< average length of all reads
		short count;                    ///< indel count
		size_t dep;                     ///< the depth of the start position of the indel
	public:
		void print_indel_info() const;
		void print_indel_info(ogzstream &ofs) const;
};
/**
 * The class is used for storing information parsed from the soap result file
 */

class soap_t
{
	private:
		string id;      			    ///< index
		string seq;				        ///< sequence string
		string qual;			        ///< quality string
		size_t nhits;				    ///< the times of success alignments
		char file;				        ///< file query
		size_t read_len;			    ///< length of the read
		char fr;				        ///< forward or reward
		string chr;				        ///< the chromosome NO.
		unsigned long pos;				///< the start position in chromosome
		string mm_indel;		        ///< mismatchs or indel information
		size_t indel_pos;			    ///< indel position
		vector<string> mminfo;          ///< mismatch detailed infomation
		string msid;			        ///< matched length including gaps
		string minfo;			        ///< detailed infomation of matching
		string indel_str;               ///< indel string
		unsigned short trim_len;        ///< trimed length in the read
		unsigned short front_trim_len;  ///< the front trimed length
		unsigned short indel_len;       ///< the size of indel
	public:

		unsigned long get_pos() const {return pos;}

		size_t get_read_len()const {return read_len;}

		size_t get_indel_pos()const {return indel_pos;}

		string get_seq()const {return seq;}

		string get_chr()const {return chr;}

		string get_mm_indel()const {return mm_indel;}

		int indel_hits_stat(map< string, map<string,indel_info> > &indel_stat_vec) const;

		int hits_stat(map<string, vector<unsigned char> > &bpstat_vec ) const;

		int parse_line(igzstream &ifs);

		int calc_trim_len();

		void print_soap() const;
};


/** @file parse.cpp
 * This is the implementation file of the 'parse' module
 */
/**
 *parse one line of the soap result
 *@param ifs the stream of a soap file
 */
int soap_t::parse_line(igzstream &ifs)
{
    string ss;
    int ntab = 0;

    getline(ifs, ss);
    ntab = count(ss.begin(), ss.end(), '\t');

    istringstream iss (ss,istringstream::in);
    iss >> id >> seq >> qual >> nhits >> file
        >> read_len >> fr >> chr >> pos >> mm_indel;

    size_t found = mm_indel.find('M');
    if (found != mm_indel.npos) {
        msid = mm_indel;
        found = mm_indel.find('I');
        if (found != mm_indel.npos) {
            indel_len = mm_indel[found - 1] - '0';

            mm_indel = string("100");
            mm_indel[2] += indel_len;
        }

        found = mm_indel.find('D');
        if (found != mm_indel.npos) {
            indel_len = mm_indel[found - 1] - '0';

            mm_indel = string("200");
            mm_indel[2] += indel_len;
        }

        found = msid.find('S');
        if (found != msid.npos) {
            int tmp = atoi(msid.c_str());
            indel_pos = tmp + atoi(msid.substr(found + 1).c_str());
        }

        indel_pos = atoi(msid.c_str());

        iss >> minfo;

    }
    ////////////////
    else { //added on 06.30 for the bad soap results which loss two columns
        if ( mm_indel.length() == 3 && isdigit(mm_indel[2])) {
            iss >> indel_pos;
            if (indel_pos >= read_len)return -1;
        }
        else {
            for (int i = 0; i < mm_indel[0] - '0'; i++) {
                string str1;
                iss >> str1;
                mminfo.push_back(str1);
            }
        }

        iss >> msid >> minfo;

    } //added on 06.30

    calc_trim_len();

    if (mm_indel.length() == 3) {
        indel_len = (mm_indel[1] - '0') * 10 + mm_indel[2] - '0';
        indel_pos -= front_trim_len; 

        if (mm_indel[0] == '1' ) {	
            size_t d_pos = minfo.find("D");
            if (d_pos == minfo.npos)return -2;

            indel_str = minfo.substr(d_pos + 1 , indel_len);
        }
        else {
            if (indel_pos  >= seq.length())return -3;
            indel_str = seq.substr(indel_pos, indel_len);
        }
    }
    else indel_len = 0;

    return 0;
}

/**
 * print the information extracted from the soap result
 */
void soap_t::print_soap()const
{
    cout << "print the read info" << endl;
    cout  << id << '\t' << seq << '\t' << qual << '\t' << nhits <<'\t' << file << '\t' << read_len << '\t' << fr << '\t' << chr << '\t' << pos << '\t' << mm_indel << endl;

    if ( mm_indel.length() > 1)cout << indel_pos << endl;
    else
        for (int i = 0; i < mm_indel[0] - '0'; i++)
            cout << mminfo[i] << '\t';

    cout << msid << '\t' << minfo << endl;

    return;
}

/**
 *if the read has been trimmed, you must calculate the trimmed length 
 */
int soap_t::calc_trim_len()
{
    string ss = msid;
    const char  *cstr = ss.c_str();  
    size_t s_pos = ss.find("S");
    const char *p ;
    trim_len = front_trim_len = 0;

    p = cstr + s_pos;
    if (s_pos != ss.npos) {
        while (isdigit(*(--p))){}

        trim_len =  atoi(++p);
        if (p == cstr) front_trim_len = trim_len;
    }
    else return 0;

    p = cstr + s_pos + 1; 
    s_pos = ss.substr(s_pos + 1).find("S");

    p += s_pos;
    if (s_pos != ss.npos)
        if (s_pos != ss.npos) {
            while (isdigit(*(--p))){}

            trim_len += atoi(++p);
        }

    return 0;
}
/**
 * statistics of hits(or depth) on every base
 */
int soap_t::hits_stat(map<string, vector<unsigned char> > &bpstat_vec )const
{
    vector<unsigned char> &bp_vec = bpstat_vec[chr];
    size_t read_len1 = read_len;
    
    if (indel_len > 0 && mm_indel[0] == '2')read_len1 = read_len - indel_len;

    if (pos + read_len1 > bp_vec.size()) return -1;

    for (size_t i = 0; i  < read_len1; i++) {
        if (bp_vec[pos + i] < 0xff)bp_vec[pos + i]++;
        else {
            //cout << "count of some base is larger than 255!!" << endl;
        }

    }

    if (mm_indel.length() == 1 && nhits > 1) {
        for (size_t i = 0; i  < read_len1; i++) {
            if (bp_vec[pos + i] < 0x7f)bp_vec[pos + i] += 128;
        }	
    }

    return 0;
}
/**
 * as the name says, print the information of an indel
 */
void indel_info::print_indel_info() const
{
    int dep1 = (type == string("del"))? (dep - count) : dep;
    cout << chr << "\t" << pos << '\t' << (char)toupper(type[0]) << size << "\t" << indel_str << "\t" << qual_sco <<  "\t" << count << '\t' << dep1 << '\t' << dep << endl;
}
/**
 *as the name says, print the information of an indel
 *@param ofs the stream of the output file
 */
void indel_info::print_indel_info(ogzstream &ofs) const
{
	//int dep1 = (type == string("del"))? (dep - count) : dep;
	ofs << chr << "\t" << pos << '\t' << (char)toupper(type[0]) << size << "\t" << indel_str << '\t' << fr <<  "\t" << pair_type << '\t' << qual_sco <<  "\t" << count << '\t' << dep << endl;

}


/**
 * check if the flanking bases have mismatchs
 * @param minfo the mismatch information string
 * @param indel_pos where thi indel occurs in the read
 * @param offset check if there are minmatchs in the interval [indel_pos - offset, indel_pos + offset]
 */
int ismismatch(const char *minfo, int indel_pos, int offset)
{
    const char *p = minfo;
    const char *p1;

    int cnt = 0;
    while (*p) {
        p1 = p;
        while (*p && !isalpha(*p) )p++;

        if (*p ) {
            cnt += atoi(p1) + 1;
            if (*p == 'D') {p++; cnt--; continue;}

            p++;
            if (cnt - indel_pos <= offset && cnt - indel_pos >= -offset) return 1;
        }
        if(*p == 'D') {p++; continue;}
    }

    return 0;
}

/** 
 *statistics of hits on every indel
 */
int soap_t::indel_hits_stat(map<string, map<string, indel_info> > &indel_stat_vec)const
{
    if (mm_indel.length() < 3)return 0;

    indel_reads_cnt++;

    int indel_ref_pos = pos + indel_pos;

    char key_str[KEY_MAX_LEN] = {0};

    //case insensitive
    char istr[1024] = {0};
    const char *p = indel_str.c_str();
    for (size_t i = 0; i < strlen(p); i++) istr[i] = toupper(*(p + i));

    //add for the position sort
    char tmpstr[32] = {0};
    sprintf(tmpstr, "%d", indel_ref_pos);
    for (size_t i = 0; i < 32 - strlen(tmpstr); i++)key_str[i] = '0';
    //add for the position sort

    sprintf(key_str + 32 - strlen(tmpstr), "%d_%s_%s", indel_ref_pos, mm_indel.c_str(), istr);
    string tmp = minfo;

    if (mm_indel[0] == '1') {
        int d_pos = tmp.find("D");
        for (int i = 0; i <= indel_len; i++)tmp[d_pos + i] = 'D';
    }	
    //if the neighbours of the indel position are mismatch positions , the indel is not so credible, it may be an alignment error
    if (ismismatch(tmp.c_str(),indel_pos, mismatch_offset)) {
        indel_discard_cnt++;	
        return -1;
    }
    string indel_key(key_str); 
    map<string, indel_info> &stat_map = indel_stat_vec[chr];
    map<string, indel_info>::iterator iter = stat_map.find(indel_key);
    //if existed indel
    if (iter != stat_map.end()){
        map<long, long>::iterator siter;
        //quality calc
        short quality = 0;
        long quality_sum=0;
        int offset1 = 5;
        size_t bmin = max(size_t(0), size_t(indel_pos - offset1));
        size_t bmax = min(qual.length(), size_t(indel_pos + offset1));

        for (size_t j = bmin; j < bmax; j++)
        {
            int A=(qual[j] - 64);
            if (A<0) {A=(qual[j] - 33) ;}
            quality_sum += A ;
        }
        quality = (short)(quality_sum/(bmax - bmin));
        iter->second.count++;
        long tmp=iter->second.qual_sco ;
        long All_quality=tmp*(iter->second.count) + quality;
        iter->second.qual_sco =(short)(All_quality/(iter->second.count));
        iter->second.read_len = (iter->second.read_len * iter->second.count + read_len)/(iter->second.count);
        if (iter->second.fr != fr) iter->second.fr = '*';
    }
    //if new indel
    else {
        if (nhits > 1)return -1; //indels in repeatedly aligned reads are discarded

        indel_info new_indel;

        new_indel.pos = pos + indel_pos;
        new_indel.size = indel_len;
        new_indel.minfo = minfo;
        new_indel.id = id;
        new_indel.chr = chr;

        if (mm_indel[0] == '1')new_indel.type = string("del");
        else new_indel.type = string("ins");
        new_indel.indel_str = indel_str;
        int offset1 = 5;
        /// consider the indel called on the edges
        size_t bmin = max(size_t(0), size_t(indel_pos - offset1));
        size_t bmax = min(size_t(qual.length()), size_t(indel_pos + offset1));

        long quality_sum = 0;
        for (size_t i = bmin; i < bmax; i++)
        {
            int A=(qual[i] - 64);
            if (A<0) { A=(qual[i] - 33);}
            quality_sum += A ;
        }
//      short quality = quality_sum/(bmax - bmin);
        new_indel.qual_sco =(short)(quality_sum/(bmax - bmin));
        new_indel.read_len = read_len;
        new_indel.count = 1;
        new_indel.fr = fr;
        stat_map.insert(pair<string, indel_info>(indel_key, new_indel));
    }
    return 0;
}
#endif

