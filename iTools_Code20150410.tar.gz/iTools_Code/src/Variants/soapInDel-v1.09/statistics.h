/** @file statistics.h
 *This is the header file of the 'statistics' module
 */  
#ifndef _STATISTICS_H_
#define _STATISTICS_H_

#include <vector>
#include <map>
#include "parse.h"
#include "threadmgr.h"

/** @file statistics.cpp
 *This is the implementation file of the 'statistics' module
 */  
#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>
#include <cstdlib>
#include <string>
#include "statistics.h"
#include "math_fun.h"
#include <pthread.h>

using namespace std;

extern char soap_file[];
extern char chrinfo[];
extern char ref_file[];                                                                                            
extern size_t ncpu;

pthread_mutex_t stat_mutex; ///< for protecting the global variable 'bpstat_vec'



int T_base_count(const char *file_name , map<string, long> & chr_count )
{
    igzstream ifs ( file_name, ifstream::in );
    if (!ifs.good()) {
        cerr << "can not open the reference file: "<< file_name  << endl;
        return 0;
    }

    string tmpstr;
    getline(ifs, tmpstr);
    while (tmpstr.find(">") == tmpstr.npos && !ifs.eof()) getline(ifs, tmpstr);

    while (!ifs.eof()) {
        istringstream iss(tmpstr.substr(tmpstr.find(">") + 1), istringstream::in);
        string chr;
        iss >> chr;
        long chr_bp_count = 0;
        while (!ifs.eof()) {
            ifs >>  tmpstr;
            if (tmpstr.find(">") != tmpstr.npos) break;
            chr_bp_count += tmpstr.length();
        }
        if (chr_bp_count == 0) continue;
        chr_count.insert(pair<string, long>(chr, chr_bp_count));
    }
    ifs.close();

    return 0;

}



/**
 * muti-threading implementation of  the statistics module
 */
class stat_thread:public thread_base
{
    private:
        size_t index;               ///< the field is used for distinguish between threads 

    public:

        map<string, map<string, indel_info> > indel_stat_vec; ///< store the statistics information of indels, only used in one thread
        map<string, vector<unsigned char> > *pbpstat_vec;     ///< store the statistics information of indels of every base-pair
        vector<string> *pfile_list;                           ///< list of files to get statistics information

        stat_thread(map<string, vector<unsigned char> > *pbpstat_vec1, vector<string> *pfile_list1): pbpstat_vec(pbpstat_vec1), pfile_list(pfile_list1) {}

        void set_index(size_t i) {index = i;}

        int soap_stat(const char *file_name);      

        int alloc_rc();

        virtual void* task();                      

        virtual ~stat_thread(){}

};

/**
 * base class of the statistics. 
 * because the members of the base class are also used in the 'validation' module and they are so common, so define it as a base class
 */
class stat_base
{
    protected:
        map<string, long> chr_count;            //store the information about length of chromosomes 
        vector<string> file_list; 

        int base_count(const char *file_name);  //get the length of chromosomes from the reference 

        int read_file_list(const char *file_list_file); //get the list of soap result files
};


class eval_t; //declare it because it is used as a friend class of the stat_t


class stat_t:protected stat_base
{
    private:
        map<string, vector<unsigned char> > bpstat_vec;         ///< store the statistics information of indels of every base-pair
        map<string,  map<string, indel_info> > indel_stat_all;  ///< merge all the indels of all pthreads


    public:
        friend class eval_t;                                    ///< set this so that  eval_t can get the member variables

        int read_chrinfo(const char *file_name);                ///< get length of chromosomes from a given file

        int alloc_rc();                                         ///< allocate memory resource

        int merge_indel_vec(vector<stat_thread> &thread_vec);   ///< merge the indel information when all threads run over

        int run_stat();                                         ///< statistics module entry
};



/**
 * read the list of .soap/.single files
 * @param file_list_file the file including the list of soap files
 */
int stat_base::read_file_list(const char *file_list_file)
{
    igzstream ifs(file_list_file, ifstream::in);
    if (!ifs.good()) {
        cerr << "can not open the file: " << file_list_file << endl;
        return 0;
    }

    while (!ifs.eof()) {
        string str;
        ifs >> str;
        if (str.length() >0) file_list.push_back(str);
    }

    ifs.close();

    return 0;
}

/**
 * count the bases of every chromosome from the reference file if the chromosome information is not given
 * @param file_name the name of the reference file
 */

int stat_base::base_count(const char *file_name)
{
    return  T_base_count(file_name ,  chr_count ) ;
    /*
    igzstream ifs ( file_name, ifstream::in );
    if (!ifs.good()) {
        cerr << "can not open the reference file: "<< file_name  << endl;
        return 0;
    }

    string tmpstr;
    getline(ifs, tmpstr);
    while (tmpstr.find(">") == tmpstr.npos && !ifs.eof()) getline(ifs, tmpstr);

    while (!ifs.eof()) {
        istringstream iss(tmpstr.substr(tmpstr.find(">") + 1), istringstream::in);
        string chr;
        iss >> chr;
        //cout << "handling chr : " << chr << endl; 

        long chr_bp_count = 0;
        while (!ifs.eof()) {
            ifs >>  tmpstr;
            if (tmpstr.find(">") != tmpstr.npos) break;
            chr_bp_count += tmpstr.length();
        }
        if (chr_bp_count == 0) continue;
        chr_count.insert(pair<string, long>(chr, chr_bp_count));
    }

    ifs.close();

    return 0;
*/
}
/**
 * read chromosome information(the length information).
 * if the file is given, it can save the time for counting the bases in the reference file
 * @param file_name the name of the reference file
 */
int stat_t::read_chrinfo(const char *file_name)
{
    cout << "in the read_chrinfo" << endl;

    igzstream ifs(file_name, ifstream::in);
    if(!ifs.good()) {
        cerr << "open file " << file_name << " error" << endl;
        return 0;
    }

    while(!ifs.eof()) {
        string nr;
        int count;
        ifs >> nr >> count;
        if (nr.length() == 0)continue;

        chr_count[nr] = count;
    }
    return 0;
}

/**
 * resource allocation
 */
int stat_t::alloc_rc()
{
    for (map<string, long>::iterator  iter = chr_count.begin(); iter != chr_count.end(); iter++) {

        cout << iter->first << '\t' << iter->second << endl;

        bpstat_vec.insert(pair<string, vector<unsigned char> >(iter->first, vector<unsigned char>()));
        bpstat_vec[iter->first].resize(iter->second, 0);

        indel_stat_all.insert(pair<string, map<string, indel_info> >(iter->first, map<string, indel_info>()));
    }

    return 0;
}
/**
 * merge the indels of all threads
 * @param thread_vec instances of the statistics threads, every one of them holds part of the information of canditate indels
 */
int stat_t::merge_indel_vec(vector<stat_thread> &thread_vec)
{
    for (size_t i = 0; i < thread_vec.size(); i++) {
        for (map<string, map<string,indel_info> >::iterator iter1 = thread_vec[i].indel_stat_vec.begin(); iter1 != thread_vec[i].indel_stat_vec.end(); iter1++) {
            const string &chr = iter1->first;
            map<string,indel_info> &stat_map1 = iter1->second;
            map<string,indel_info> &stat_map2 = indel_stat_all[chr];

            for (map<string,indel_info>::iterator iter2 = stat_map1.begin(); iter2 != stat_map1.end(); iter2++) {
                map<string,indel_info>::iterator siter = stat_map2.find(iter2->first);
                if (siter == stat_map2.end()) {
                    stat_map2.insert(*iter2);
                }
                else {
                    long Q_A=siter->second.qual_sco;
                    long Q_B=iter2->second.qual_sco;
                    siter->second.count += (iter2->second.count);
                    long All_Q=Q_A * siter->second.count + Q_B * iter2->second.count;
                    siter->second.qual_sco = (short)(All_Q/(siter->second.count));
                    if (iter2->second.fr != siter->second.fr) siter->second.fr = '*';
                }
            }
        }

        thread_vec[i].indel_stat_vec.clear();
    }

    return 0;
}

/**
 * the entry of the 'statistics' module
 */
int stat_t::run_stat()
{
    if (strlen(chrinfo) == 0)base_count(ref_file);
    else read_chrinfo(chrinfo);

    alloc_rc();

    pthread_mutex_init(&stat_mutex, NULL);    
    read_file_list(soap_file);

    if (file_list.size() == 0) {cerr << "no file to stat" << endl;return 0;}
    else {
        cout << file_list.size() << " files to stat" << endl;
    }

    vector<stat_thread> thread_vec(ncpu, stat_thread(&bpstat_vec, &file_list));

    for (size_t i = 0; i < thread_vec.size(); i++) {
        thread_vec[i].alloc_rc();
        thread_vec[i].set_index(i);
        thread_vec[i].run();
    }

    for (size_t i = 0; i < thread_vec.size(); i++) {
        thread_vec[i].join(NULL);
    }

    merge_indel_vec(thread_vec); 
    return 0;
}
/**
 * resource allocation of one thread
 */
int stat_thread::alloc_rc()
{
    for (map<string, vector<unsigned char> >::iterator iter = pbpstat_vec->begin(); iter != pbpstat_vec->end(); iter++) {
        indel_stat_vec.insert(pair<string, map<string, indel_info> >(iter->first, map<string, indel_info>()));
    }

    return 0;
}
/**
 * get the statistics information of every file
 * @param file_name the name of a soap result file
 */
int stat_thread::soap_stat(const char *file_name)
{
    //map<string, vector<unsigned char> > &bpstat_vec = *pbpstat_vec;

    igzstream ifs ( file_name, ifstream::in );
    if (!ifs) {
        cerr << "open soap file error: " << file_name << endl;
        return 0;
    }
    //cout << "in the soap_stat" << endl; 

    int i = 0;
    while (!ifs.eof()) {
        i++;
        soap_t soapvar1;
        //soap_t soapvar2;

        if (soapvar1.parse_line(ifs) != 0) continue;
        //ret2 = soapvar2.parse_line(ifs);

        pthread_mutex_lock(&stat_mutex);
        int ret = soapvar1.hits_stat(*pbpstat_vec);
        pthread_mutex_unlock(&stat_mutex);

        if( ret >= 0) {
            soapvar1.indel_hits_stat(indel_stat_vec);
        }

    }

    ifs.close();
    return 0;
}

/**
 * the task of the thread instance. if a class is inheriting from the thread_base class, the task() member function must be defined.
 */ 
void* stat_thread::task()
{
    size_t len = pfile_list->size() / ncpu;
    size_t n = index;

    for (size_t i = n * len; i < (n + 1) * len; i++) {
        cout << "stating file : " << (*pfile_list)[i].c_str() << endl;
        soap_stat((*pfile_list)[i].c_str());
    }

    if (n == ncpu -1) {
        for (size_t i = ncpu * len; i < pfile_list->size(); i++) {
            cout << "stating file : " << (*pfile_list)[i].c_str() << endl;
            soap_stat((*pfile_list)[i].c_str());
        }
    }

    return NULL;
}



#endif
