#ifndef BERT_TTYAUTO_H
#define BERT_TTYAUTO_H

#include <unistd.h>
#include <termios.h>
#include <sys/ioctl.h>
#include "Singleton.h"


class TtyAuto : public Singleton<TtyAuto>
{
	friend class Singleton<TtyAuto>;
	friend class std::auto_ptr<TtyAuto>;

	struct termios m_state;

	private:

	//  构造函数,自动设置非缓冲，非回显模式
	TtyAuto()
	{
		tcgetattr(STDIN_FILENO, &m_state);
		m_state.c_lflag &= ~ICANON;
		m_state.c_lflag &= ~ECHO;
		tcsetattr(STDIN_FILENO, TCSANOW, &m_state);
	}

	//  析构函数,自动恢复缓冲，回显模式
	~TtyAuto()
	{
		m_state.c_lflag |= ICANON;
		m_state.c_lflag |= ECHO;
		tcsetattr(STDIN_FILENO, TCSANOW, &m_state);
	}
};

#endif

