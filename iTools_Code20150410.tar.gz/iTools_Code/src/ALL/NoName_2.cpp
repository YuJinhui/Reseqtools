#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include </ifs1/STT_POP/USER/heweiming/bin/Genotype/Test/gzstream.h>
using namespace std;

///////////////////
string &  replace_all(string &  str,const   string&  old_value,const string&   new_value)      
{      
    while(true)   {      
        string::size_type   pos(0);      
        if(   (pos=str.find(old_value))!=string::npos   )      
            str.replace(pos,old_value.length(),new_value);      
        else   break;      
    }      
    return   str;      
}      

string &   replace_all_distinct(string&   str,const   string&   old_value,const   string&   new_value)      
{      
    for(string::size_type   pos(0);   pos!=string::npos;   pos+=new_value.length())   {      
        if(   (pos=str.find(old_value,pos))!=string::npos   )      
            str.replace(pos,old_value.length(),new_value);      
        else   break;      
    }      
    return   str;      
}      
void split(const string& str,vector<string>& tokens,  const string& delimiters = " ")
{
    string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    string::size_type pos     = str.find_first_of(delimiters, lastPos);
    while (string::npos != pos || string::npos != lastPos)
    {
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        lastPos = str.find_first_not_of(delimiters, pos);
        pos = str.find_first_of(delimiters, lastPos);
    }
}
///////////////////


int GetShiftQXam ( string XAMPath ,int A )
{
	char in_mode[5] ={ 0 };
	in_mode[0]='r';
	if ( A==2 )
	{
		in_mode[1]='b';
	}
	TSamCtrl samhandle;
	samhandle.open(sampath.c_str(),in_mode);

	int minQ=50000;
	int maxQ=0;
	string line ;
	for ( int A=1 ; ( A<88888 && (samhandle.readline(line)!=-1) )  ; A++ )
	{
		if (line.length()<=0)  { continue  ; }
		vector<string> inf;
		split(line,inf," \t");

		string::size_type SeqQLength =(inf[10]).size();
		for(int i=0 ; i<SeqQLength ; i++)
		{
			if(minQ>(inf[10])[i])
			{
				minQ=(inf[10])[i];
			}
			if(maxQ<(inf[10])[i])
			{
				maxQ=(inf[10])[i];
			}
		}
	}
	INXAM.close();
	if(minQ >= 33 &&  minQ <= 74  &&  maxQ >= 33 && maxQ <=74 )
	{
		return 33;
	}
	else if (minQ >= 64  &&  minQ <= 105  &&  maxQ >= 64 && maxQ <= 105)
	{
		return 64;
	}
	else
	{
		return 64 ;
	}
}


int main(int argc,char *argv[])
{

    if(argc!=3)
    {
        cout<<"\tVersion 1.0\thewm@genomics.org.cn\t2015-01-20\n";
        cout<<argv[0]<<"\tInPut\tOutPut"<<endl;
        return 1 ;
    }
    string InputFile=argv[1] ;
        return 0 ;
}
////////////////////////swimming in the sea & flying in the sky //////////////////


