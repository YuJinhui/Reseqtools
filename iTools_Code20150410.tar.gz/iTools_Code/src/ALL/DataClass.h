
////////////////////////swimming in the sea & flying in the sky //////////////////


/*
 * DataClass.h
 *
 *  Created on: 2011-11-21
 *      Author: hewm@genomics.org.cn
 */

#ifndef DataClass_H_
#define DataClass_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cmath>
#include <iomanip>
#include <cassert>
#include <cstdlib>

using namespace std;

typedef char Base;
typedef unsigned long long   ubit64_t;
typedef long double LDBL ;

string   Int2Base[4][4]=
{
	{"A", "M" , "W" , "R" },

	{"M", "C" , "Y" , "S" },

	{"W", "Y" , "T" , "K" },

	{"R", "S" , "K" , "G" },
} ;

Base ArryBase[5]={'A','C','T','G','N'};
string BaseNum[5]={"A","C","T","G","N"};



LDBL get_quality_error ( char Q , int minQ )
{
	int Q_int=Q-minQ ;
	//cerr<<"Qming:"<<(para->minQ)<<endl;
	LDBL error=pow(10,-0.1*Q_int);
	return error ;
} ;


double  get_het( int A_length ,int B_length , double HET )
{
	double het_pr=0.25-0.05*((A_length+B_length)/5);
	double AB_het=max(HET,het_pr);
	if  ( B_length==0 || A_length==0 )
	{
		AB_het=HET;
	} 
	return AB_het ;
}


///////////////// q_seq  for site ////////
class Site {

	string q_base[5];
	int sum_hit ;

	public:

	Site ( void )
	{
		q_base[0]=q_base[1]=q_base[2]=q_base[3]=q_base[4]="";
		sum_hit=0;
	}

	int  Add_Quality (Base A ,Base QA,int hit )
	{        
		A=toupper(A);
		if (A == 'N') {return 0 ;}
		else
		{
			int alleleA_Num=((A>>1)&3);            
			q_base[alleleA_Num]= q_base[alleleA_Num]+QA ;
			sum_hit+=hit ;
			return 1 ;
		}
	}

	void Destory_Site()
	{
		q_base[0]=q_base[1]=q_base[2]=q_base[3]=q_base[4]="";
		sum_hit=0;
		//    return 1 ;
	}

	string get_q(int bin_base) 
	{
		return q_base[bin_base];
	}
	int get_hit() 
	{
		return sum_hit ;
	}


	int  CopySame ( Site B )
	{
		q_base[0]=B.get_q(0);
		q_base[1]=B.get_q(1);
		q_base[2]=B.get_q(2);
		q_base[3]=B.get_q(3);
		sum_hit=B.get_hit();
		return 1; 
		//    return *this ;
	}

	string get_q(Base A)
	{
		int bin_base=((A>>1)&3);
		return q_base[bin_base];
	}
	int get_q_length(int A) 
	{
		int length=(q_base[A]).length();
		return length ;
	}

	int get_q_length(Base A) 
	{
		int bin_base=((A>>1)&3);
		int length=(q_base[bin_base]).length();
		return length ;
	}

	int get_Two_allele(int  Ref , Base & B , int & Ref_length , int & B_length )
	{
		//        int RefAllele=((Ref>>1)&3) ;
		Ref_length=q_base[Ref].length();
		int tmpB=4;
		B_length=0;
		for (int i=0 ; i<4 ; i++)
		{
			if (Ref^i)
			{
				int tmpL=q_base[i].length();
				if (B_length<tmpL)
				{
					tmpB=i; 
					B_length=tmpL ;
				}
			}
		}
		B=ArryBase[tmpB];
		return tmpB ;
	}

	double get_mean_hit( int & SumDepth )
	{
		if (sum_hit==0)
		{
			SumDepth=0;
			return 25.0 ;
		}
		else
		{
			SumDepth=((q_base[0]).length())+((q_base[1]).length())+((q_base[2]).length())+((q_base[3]).length()) ;
			double mean_hit=(sum_hit*1.0)/(SumDepth) ;
			return mean_hit ;
		}
	}

	string  Genotype_Likelihood ( int A , int  B ,int A_length, int B_length ,int minQ )
	{
		LDBL A_LLHD=1 ;
		LDBL B_LLHD=1 ;
		A_length = (A_length<125)?A_length:125;
		B_length = (B_length<125)?B_length:125;

		for(int ix=0 ; ix<A_length  ; ix++)
		{
			LDBL  A_ix_error=get_quality_error (q_base[A][ix] , minQ );
			A_LLHD=A_LLHD*(1-A_ix_error);
			B_LLHD=B_LLHD*A_ix_error ;
		}

		for(int ix=0 ; ix<B_length  ; ix++)
		{
			LDBL  B_ix_error=get_quality_error (q_base[B][ix],  minQ);
			B_LLHD=B_LLHD*(1-B_ix_error);
			A_LLHD=A_LLHD*B_ix_error ;
		}
		string genotype="N";

		if (A_LLHD>=B_LLHD )
		{
			genotype=BaseNum[A];
		}
		else
		{
			genotype=BaseNum[B];
		}

		return genotype  ; 
	}

	string Genotype_Likelihood(int A ,int B,int A_length, int B_length , int minQ , double HET )
	{
		LDBL AA_LLHD=1.0 ;
		LDBL AB_LLHD=1.0 ;
		LDBL BB_LLHD=1.0 ;
		A_length = (A_length<125)?A_length:125;
		B_length = (B_length<125)?B_length:125;

		for(int ix=0 ; ix<A_length ; ix++)
		{
			LDBL  A_ix_error=get_quality_error ((q_base[A])[ix] , minQ); 
			AA_LLHD=AA_LLHD*(1-A_ix_error);
			BB_LLHD=BB_LLHD*A_ix_error ;
			AB_LLHD=AB_LLHD*0.5;
		}
		for(int ix=0 ; ix<B_length ; ix++)
		{
			LDBL  B_ix_error=get_quality_error ((q_base[B])[ix] ,  minQ);
			BB_LLHD=BB_LLHD*(1-B_ix_error);
			AA_LLHD=AA_LLHD*B_ix_error ;
			AB_LLHD=AB_LLHD*0.5;
		}

		double ABHet= get_het(  A_length , B_length, HET ) ;
		double Bland=(1-ABHet)/2.0 ;
		LDBL P_AA=Bland*AA_LLHD;  LDBL P_BB=Bland*BB_LLHD;  LDBL P_AB=ABHet*AB_LLHD;
		string genotype="N";

		if (P_AA>=P_BB && P_AA>=P_AB )
		{
			genotype=Int2Base[A][A];
		}
		else if (P_BB>P_AB)
		{
			genotype=Int2Base[B][B];
		}
		else
		{
			genotype=Int2Base[A][B];
		}

		return genotype  ; 
	}


	string Genotype( int &  B_length , int MinQ )
	{

		int A=0 , A_length=q_base[0].length();
		for (int ii=1 ; ii<4 ; ii++)
		{
			int Len=q_base[ii].length() ;
			if (A_length<Len)
			{
				A=ii ; 
				A_length=Len ;
			}
		}
		if (A_length==0) {return "N"  ;}

		int B=4 ;
		B_length=0 ;
		for (int i=0 ; i<4 ; i++)
		{
			if (A^i)
			{
				int tmpL=q_base[i].length();
				if (B_length<tmpL)
				{
					B=i; 
					B_length=tmpL ;
				}
			}
		}

		LDBL AA_LLHD=1.0 ;
		LDBL AB_LLHD=1.0 ;
		LDBL BB_LLHD=1.0 ;
		A_length = (A_length<125)?A_length:125;
		B_length = (B_length<125)?B_length:125;

		for(int ix=0 ; ix<A_length ; ix++)
		{
			LDBL  A_ix_error=get_quality_error ((q_base[A])[ix] , MinQ ); 
			AA_LLHD=AA_LLHD*(1-A_ix_error);
			BB_LLHD=BB_LLHD*A_ix_error ;
			AB_LLHD=AB_LLHD*0.5;
		}
		for(int ix=0 ; ix<B_length ; ix++)
		{
			LDBL  B_ix_error=get_quality_error ((q_base[B])[ix] , MinQ );
			BB_LLHD=BB_LLHD*(1-B_ix_error);
			AA_LLHD=AA_LLHD*B_ix_error ;
			AB_LLHD=AB_LLHD*0.5;
		}

		double ABHet= get_het(  A_length , B_length, 0.001 ) ;
		double Bland=(1-ABHet)/2.0 ;
		LDBL P_AA=Bland*AA_LLHD;  LDBL P_BB=Bland*BB_LLHD;  LDBL P_AB=ABHet*AB_LLHD;
		string genotype="N";

		if (P_AA>=P_BB && P_AA>=P_AB )
		{
			genotype=Int2Base[A][A];
		}
		else if (P_BB>P_AB)
		{
			genotype=Int2Base[B][B];
		}
		else
		{
			genotype=Int2Base[A][B];
		}

		return genotype  ; 
	}




	string Genotype( int &  B_length ,int MinQ , char Abase )
	{
		int A=((Abase>>1)&3), A_length=q_base[A].length();
		int B=4; B_length=0 ;
		for (int i=0 ; i<4 ; i++)
		{
			if (A^i)
			{
				int tmpL=q_base[i].length();
				if (B_length<tmpL)
				{
					B=i; 
					B_length=tmpL ;
				}
			}
		}
		LDBL AA_LLHD=1.0 ;
		LDBL AB_LLHD=1.0 ;
		LDBL BB_LLHD=1.0 ;
		A_length = (A_length<125)?A_length:125;
		B_length = (B_length<125)?B_length:125;

		for(int ix=0 ; ix<A_length ; ix++)
		{
			LDBL  A_ix_error=get_quality_error ((q_base[A])[ix] , MinQ ); 
			AA_LLHD=AA_LLHD*(1-A_ix_error);
			BB_LLHD=BB_LLHD*A_ix_error ;
			AB_LLHD=AB_LLHD*0.5;    
		}

		for(int ix=0 ; ix<B_length ; ix++)
		{
			LDBL  B_ix_error=get_quality_error ((q_base[B])[ix] ,  MinQ );
			BB_LLHD=BB_LLHD*(1-B_ix_error);
			AA_LLHD=AA_LLHD*B_ix_error ;
			AB_LLHD=AB_LLHD*0.5;
		}

		double ABHet= get_het(  A_length , B_length, 0.001 ) ;
		double Bland=(1-ABHet)/2.0 ;
		LDBL P_AA=Bland*AA_LLHD;  LDBL P_BB=Bland*BB_LLHD;  LDBL P_AB=ABHet*AB_LLHD;
		string genotype="N";

		if (P_AA>=P_BB && P_AA>=P_AB )
		{
			genotype=Int2Base[A][A];
		}
		else if (P_BB>P_AB)
		{
			genotype=Int2Base[B][B];
		}
		else
		{
			genotype=Int2Base[A][B];
		}

		return genotype  ; 
	}
	
	////////swimming in the sky and flying in the sea *///////////
} ;




class In3str1v {
	public:
		string InStr1 ;
		string InStr2 ;
		string InStr3 ;
		vector <string> List ;
		bool  TF ;
		int   InInt ;
		bool TF2 ;
		In3str1v()
		{
			InStr1="";
			InStr2="";
			InStr3="";
			TF=true ;
			TF2=true ;
			InInt=0 ;
		}
};


#endif /* DataClass_H_ */

//////////////// swimming in the sky and flying in the sea ////////////////
