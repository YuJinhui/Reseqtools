
int GetShiftQXam ( string XAMPath ,int A )
{
	char in_mode[5] ={ 0 };
	in_mode[0]='r';
	if ( A==3 )
	{
		in_mode[1]='b';
	}
	TSamCtrl samhandle;
	samhandle.open(XAMPath.c_str(),in_mode);

	int minQ=50000;
	int maxQ=0;
	string line ;
	for ( int A=1 ; ( A<88888 && (samhandle.readline(line)!=-1) )  ; A++ )
	{
		if (line.length()<=0)  { continue  ; }
		vector<string> inf;
		split(line,inf," \t");

		string::size_type SeqQLength =(inf[10]).size();
		for(int i=0 ; i<SeqQLength ; i++)
		{
			if(minQ>(inf[10])[i])
			{
				minQ=(inf[10])[i];
			}
			if(maxQ<(inf[10])[i])
			{
				maxQ=(inf[10])[i];
			}
		}
	}
	
	if(minQ >= 33 &&  minQ <= 74  &&  maxQ >= 33 && maxQ <=74 )
	{
		return 33;
	}
	else if (minQ >= 64  &&  minQ <= 105  &&  maxQ >= 64 && maxQ <= 105)
	{
		return 64;
	}
	else
	{
		return 64 ;
	}
}


#endif // comm_H_  ;



