#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"

using namespace std;

int  print_usage_3()
{
	cout <<""
		"\n"
		"\tUsage: ExtractCns -InPut <in.cns> -OutPut <out.cns>\n"
		"\n"
		"\t\t-InPut    <str>  Input the CNS file\n"
		"\t\t-OutPut   <str>  Output of the Potential snp\n"
		"\n"
		"\t\t-help            show this help\n"
		"\n";
	return 1;
}



int parse_cmd_3(int argc, char **argv,In3str1v * para_3)
{
	if (argc <=2 ) {print_usage_3();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_3->InStr1=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_3->InStr2=argv[i];
		}
		else if (flag  == "help")
		{
			print_usage_3();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_3->InStr1).empty() ||  (para_3->InStr2).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	para_3->InStr2=add_Asuffix(para_3->InStr2);

	return 1 ;
}


int extract_main(int argc,char *argv[])
{
	In3str1v * para_3 = new In3str1v;
	if (parse_cmd_3(argc, argv,para_3 )==0)
	{
		delete  para_3 ;
		return 0;
	}
	igzstream IN (para_3->InStr1.c_str(),ifstream::in); // igzstream
	ogzstream OUT ((para_3->InStr2).c_str()); //

	if(!IN.good())
	{
		cerr << "open InputFile error: "<<para_3->InStr1<<endl;
		return 0;
	}

	if(!OUT.good())
	{
		cerr << "open OUT File error: "<<para_3->InStr2<<endl;
		return 0;
	}

	long pre_posi=-1000000  ;
	string chr_id ,ref_base ,Final_base,base_F  , base_S  ;
	//int Quetly_all , Quetly_F ,  F_Uniq_depth , F_depth ,Quetly_S ,S_Uniq_depth,S_depth,All_Depth ;

	long position , dist  , temp_dist=0;
	string chr_id_temp , line_middle ;

	////////////////////////swimming in the sea & flying in the sky //////////////////   
	while(!IN.eof())
	{
		string  line ;
		getline(IN,line);
		if (line.length()<=0)  { continue ; }
		istringstream isone (line,istringstream::in);
		isone>>chr_id>>position>>ref_base>>Final_base  ;
		//        isone>>chr_id>>position>>ref_base>>Final_base>>Quetly_all>>base_F>>Quetly_F>>F_Uniq_depth>>F_depth>>base_S>>Quetly_S>>S_Uniq_depth>>S_depth>>All_Depth ;
		if ( ref_base=="N"  ||   ref_base==Final_base  )  { continue ; } 
		//          if ( ref_base!=Final_base   && ref_base!="N"  )         {
		dist=position-pre_posi ;
		if  ( chr_id_temp==chr_id )
		{
			if (dist<temp_dist)
			{
				temp_dist=dist ;
			}
			OUT<<line_middle<<"\t"<<temp_dist<<endl ;
			line_middle=line ; temp_dist=dist ;
			pre_posi=position ;
		}
		else if (chr_id_temp.empty())
		{
			chr_id_temp=chr_id ;
			line_middle=line ;
			temp_dist=dist;
			pre_posi=position ;
		}
		else 
		{
			if (line_middle.empty())
			{
				cerr<<"Something Worong in the "<<chr_id<<"\t"<<position<<endl;
				return 1;
			}
			else 
			{
				OUT<<line_middle<<"\t"<<temp_dist<<endl ;
				line_middle=line ;
				temp_dist=(position+1000000);
				chr_id_temp=chr_id ;
				pre_posi=position ;
			}
		}
		//          }
		// chr05   122     G       A       39      A       29      36      36      T       12      6       6       46      1.00000   1.00000 0       226
	}
	IN.close();
	if (!line_middle.empty())
	{
		OUT<<line_middle<<"\t"<<temp_dist<<endl ;
	}
	OUT.close();
	delete para_3 ;
	return 0;
}


////////////////////////swimming in the sea & flying in the sky //////////////////
/////////

////////////////////////swimming in the sea & flying in the sky //////////////////


