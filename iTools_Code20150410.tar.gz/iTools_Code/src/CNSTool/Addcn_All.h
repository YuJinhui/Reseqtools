#include <iostream>
#include "../include/gzstream/gzstream.h"
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <map>
#include "../ALL/comm.h"
//#include <hash_map>
//#include </opt/blc/gcc-4.5.0/include/c++/4.5.0/backward/hash_map> 
#include <string>
#include <ctime>
#include <algorithm>
//#include <ext/hash_map>
using namespace std ;
using namespace __gnu_cxx;

/// ///////swimming in the sea & flying in the sky ////////////

int  print_usage_6()
{
	cout <<""
		"\n"
		"\tUsage: Addcn -raw <in.raw> -soaplist <SoapBychr.list> -output <out.addcn>\n"
		"\n"
		"\t\t-raw       <str>   Input file of GLFmulti raw\n"
		"\t\t-soaplist  <str>   soap by chr list\n"
		"\t\t-output    <str>   output addcn file with copyberNum\n"
		"\t\t-chrleng   <int>   The length of the chr ref\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


class Para_6 {
	public:
		string raw ;
		string soaplist ;
		string output ;
		int chrleng ;
		Para_6()
		{
			chrleng=0;
			raw="";
			soaplist="";
			output="";
		}
};




int parse_cmd_6(int argc, char **argv, Para_6 * para_6)
{
	if (argc <=2 ) {print_usage_6();return  0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "raw" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_6->raw=argv[i];
		}
		else if (flag  ==  "soaplist")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_6->soaplist=(argv[i]);
		}
		else if (flag  ==  "chrleng")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_6->chrleng=atol(argv[i]);
		}
		else if (flag  ==  "output")
		{
			if(i + 1 == argc) {LogLackArg(flag);return  0;}
			i++;
			para_6->output=argv[i];
		}
		else if (flag  == "help")
		{
			print_usage_6();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return  0;
		}
	}
	if  ((para_6->raw).empty() ||  (para_6->soaplist).empty() ||   (para_6->output).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return  0;
	}
	para_6->output=add_Asuffix(para_6->output);
	if ( (para_6->chrleng) < 10)
	{
		cerr<<"chr lenth must in"<<endl;
		return  0; 
	}
	return 1 ;
}













int Addcn_main(int argc,char *argv[])
{

	Para_6 * para_6 = new Para_6;
	if( parse_cmd_6(argc, argv ,  para_6 )==0 )
	{
		delete  para_6 ;
		return  0 ;
	}
	clock_t start_time = clock();
	clock_t end_time ;

	string soaplist_file=para_6->soaplist;
	string raw_file=para_6->raw ;
	string output_file=para_6->output ;
	int chr_length=para_6->chrleng ;
	chr_length+=2 ;
	pair <int,int> temp ;
	temp=make_pair(0,0) ;
	vector <pair <int,int> > Info (chr_length,temp) ;

	igzstream  List (soaplist_file.c_str(),ifstream::in);
	igzstream  raw  (raw_file.c_str(),ifstream::in); 

	ogzstream out_fs(output_file.c_str()); 
	//ofstream out_fs(output_file.c_str()); 


	if(!List.good())
	{
		cerr << "open soap list error: "<<soaplist_file<<endl;
		return 0;
	}
	if(!raw.good())
	{
		cerr << "open RawFile error: "<<raw_file<<endl;
		return 0;
	}

	while(!List.eof())
	{
		string soapfile;
		getline(List,soapfile);
		if(soapfile.length() > 0 )
		{
			cout<<"SoapFile\t"<<soapfile<<endl;
			igzstream  soap (soapfile.c_str(),ifstream::in);
			//            ifstream soap (soapfile.c_str(),ifstream::in);
			string id,seq,qua,ab,zw,chr;
			int hit ,length,start;
			if(!soap.good())
			{
				cerr<<"open soap error: "<<soapfile<<endl;
				return 0;
			}
			while(!soap.eof())
			{
				string  line ;
				getline(soap,line);
				int position ;
				if(line.length() > 0 )     
				{
					istringstream isone (line,istringstream::in);
					isone>>id>>seq>>qua>>hit>>ab>>length>>zw>>chr>>start ;
					for (int ii=0 ; ii<length ; ii++)
					{
						position = start+ii ;  
						(Info[position].first)++;
						(Info[position].second)+=hit;
						//                     map_hit[position]+=hit ;
						//                    map_depth[position]++;
					}
				}
			}
			soap.close();
		}
	}
	List.close();

	// chr31   3003853 T       57      0.101521        T       G       27      3     20 //
	while(!raw.eof())
	{
		string  line ;
		getline(raw,line);
		if(line.length() > 0 )         {
			string chr ; 
			int posi ;
			istringstream isone(line,istringstream::in);
			isone>>chr>>posi ;
			if (Info[posi].first!=0)
				//            if(map_depth.count(posi))
			{
				double mean_hit=(double(Info[posi].second+0.0)/double(Info[posi].first+0.0));
				//<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2);
				//                out_fs<<line<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<mean_hit<<"\t"<<map_hit[posi]<<"\t"<<map_depth[posi]<<endl;
				out_fs<<line<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<mean_hit<<endl;
			}
			else
			{
				out_fs<<line<<"\t25.00"<<endl;
			}
		}
	}
	raw.close();
	out_fs.close();
	end_time = clock();
	delete para_6 ;
	Info.clear();
	cout << "time elapsed : " << (end_time - start_time) / (float)CLOCKS_PER_SEC << endl;
	return  0 ;

}



////////////////////////swimming in the sea & flying in the sky //////////////////



////////////////////////swimming in the sea & flying in the sky //////////////////
///////// swimming in the sky and flying in the sea ////////////
