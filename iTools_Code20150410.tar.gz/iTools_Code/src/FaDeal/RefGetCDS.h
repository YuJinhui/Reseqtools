#ifndef RefGetCDS_H_
#define RefGetCDS_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include "CDS2Pep.h"

//KSEQ_AINIT(gzFile, gzread)

using namespace std;
typedef long long  llong ;

int  print_AusageFA04()
{
	cout <<""
		"\n"
		"\tUsage: getCdsPep -Ref <in.fa> -Gff <in.gff>  -OutPut <out> \n"
		"\n"
		"\t\t-Ref       <str>   Input Ref fa\n"
		"\t\t-Gff       <str>   Input Ref gff\n"
		"\t\t-OutPut    <str>   Output cds seq file \n"        
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_AcmdFA04(int argc, char **argv , In3str1v * paraFA04 )
{
	if (argc <=2 ) {print_AusageFA04();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "Ref" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr1=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr2=argv[i];
		}
		else if (flag  ==  "Gff")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr3=argv[i];
		}
		else if (flag  == "help")
		{
			print_AusageFA04();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA04->InStr1).empty() || (paraFA04->InStr2).empty() ||  (paraFA04->InStr3).empty()   )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}


	return 1 ;
}

int FA_GetCDS_main(int argc, char *argv[])
{
	In3str1v *paraFA04 = new In3str1v;
	if( parse_AcmdFA04(argc, argv, paraFA04 )==0)
	{
		delete  paraFA04 ;
		return 0 ;
	}

	map <string,map <string ,bool> > GeneList;
	map <string,map <llong,llong> >  CDSList ;

	igzstream  MRG ((paraFA04->InStr3).c_str(),ifstream::in);
	if(!MRG.good())
	{
		cerr << "open InputFile error: "<<(paraFA04->InStr3)<<endl;
		delete  paraFA04 ; return 0;
	}

	while(!MRG.eof())
	{
		string  line ;
		getline(MRG,line);
		if (line.length()<=0  || line[0] == '#' )  { continue  ; }
		istringstream isone (line,istringstream::in);
		string chr , flag , CDS , ZhengFu ,geneID ;
		llong Start,End ;
		isone>>chr>>flag>>CDS ;
		if (CDS  != "CDS" )  { continue  ; }
		isone>>Start>>End>>flag>>ZhengFu>>flag>>geneID ;
		vector<string> inf;
		vector<string> Temp;
		split(geneID,inf,",;");
		split(inf[0],Temp,"=");
		string GeneID= Temp[Temp.size()-1] ;
		for ( int jk=1;  jk<inf.size() ; jk++)
		{
			vector<string> Temptmp2;
			split(inf[jk],Temptmp2,"=");
			if (Temptmp2[0] == "Parent")
			{
				GeneID= Temptmp2[Temptmp2.size()-1] ;
			}
		}

		map  <string,map <llong,llong> >  :: iterator it=CDSList.find(GeneID);
		if (it == CDSList.end() )
		{
			bool A=false ;
			if (ZhengFu == "-")
			{
				A=true ;
			}
			map <string,map <string ,bool> > :: iterator X =GeneList.find(chr);
			if (X==GeneList.end())
			{
				map <string,bool> First;
				First[GeneID]=A;
				GeneList.insert(map <string,map <string ,bool> > :: value_type(chr,First));
			}
			else
			{
				(X->second).insert(map <string ,bool>  :: value_type(GeneID ,A ));
			}
			map <llong,llong> DD;
			DD[Start]=End ;
			CDSList.insert(map <string,map <llong,llong> > ::value_type(GeneID,DD));
			//CDSList
		}
		else
		{
			(it->second).insert(map <llong,llong>  :: value_type(Start,End)) ;
		}
	}

	MRG.close();


	int linecut= FaCutLine ((paraFA04->InStr1));


	gzFile fp;
	kseq_t *seq;
	int l;

	//    (paraFA04->InStr2)=add_Asuffix(paraFA04->InStr2) ;
	string outpath=(paraFA04->InStr2)+".cds.fa.gz";
	fp = gzopen((paraFA04->InStr1).c_str(), "r");
	seq = kseq_init(fp);    
	ogzstream OUT ((outpath).c_str());

	if(!OUT.good())
	{
		cerr << "open OUT File error: "<<(outpath)<<endl;
		delete  paraFA04 ; return  0;
	}

	map <char ,char >  Complement;
	Complement['A']='T'; Complement['C']='G';  Complement['T']='A'; Complement['G']='C'; Complement['N']='N';
	Complement['a']='t'; Complement['c']='g';  Complement['t']='a'; Complement['g']='c'; Complement['n']='n';
	Complement['M']='K'; Complement['R']='Y';  Complement['W']='W'; Complement['S']='S'; Complement['Y']='R';
	Complement['K']='M';

	while ((l = kseq_read(seq)) >= 0)
	{
		string chr=seq->name.s ;
		map <string,map <string,bool> > :: iterator it=GeneList.find(chr);
		if (it != GeneList.end())
		{
			string Ref= seq->seq.s ;
			map <string,bool> ::iterator  Y ;
			for(  Y=(it->second).begin() ; Y!= (it->second).end(); Y++ )
			{
				bool TF=Y->second;
				map  <string,map <llong,llong> > :: iterator mCDS=CDSList.find(Y->first);
				string BB ;
				map <llong,llong> :: iterator PUPU ;
				for(  PUPU=(mCDS->second).begin() ; PUPU!= (mCDS->second).end(); PUPU++ )
				{
					llong START=(PUPU->first)-1 ;
					int Leng=(PUPU->second)-START;
					BB=BB+Ref.substr(START,Leng) ;
				}
				if (TF)
				{
					reverse(BB.begin(), BB.end());
					int leng=BB.size();
					for (int i=0 ; i<leng ; i++)
					{
						BB[i]=Complement[BB[i]];
					}
				}
				transform(BB.begin(), BB.end(), BB.begin(),::toupper);
				string ID=(Y->first)+"\t"+(it->first) ;
				Display(BB , ID ,  OUT ,linecut  );
			}
		}
	}
	OUT.close();
	kseq_destroy(seq);
	gzclose(fp);
	string PP= (paraFA04->InStr2)+".pep.fa.gz";
	char * A = const_cast<char*>((PP).c_str());
	char * B = const_cast<char*>((outpath).c_str());
	char * ssTmp[5]={"CDS2Pep", "-InCDS", B ,"-OutPut",A};
	FA_CDS2Pep_main( 5 , ssTmp ) ;
	delete paraFA04 ;
	return 0;
}
#endif // RefGetCDS_H_ //
///////// swimming in the sky and flying in the sea ////////////

