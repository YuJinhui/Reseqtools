#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"

using namespace std;

class ParaA35 {
	public:
		string InFA ;
		string OutPut ;
		string pattern ;
		string unpattern ;
		string getID ;
		string GetIDList ;
		ParaA35()
		{
			InFA="";
			OutPut="";
			pattern="";
			unpattern="";
			getID="";
			GetIDList="";
		}
};


int  print_AusageA35()
{
	cout <<""
		"\n"
		"\tUsage: getSP  -InFa <in.cds.fa>  -Pattern 'AK'\n"
		"\n"
		"\t\t-InFa       <str>  Input Fa for get specifed Seq\n"
		"\n"
		"\t\t-GetID      <str>  Get one sequence by specified ID\n"
		"\t\t-GetIDList  <str>  Get multi-Seq by input-file(FirstRow:IDList)\n"
		"\t\t-Pattern    <str>  Get out Seq that can match the specifed word\n"
		"\t\t-UnPattern  <str>  Get out Seq that can unmatch the specifed word\n"
		"\n"
		"\t\t-OutPut     <str>  Output Fasta File or [STDOUT]\n"
		"\t\t-help              Show this help\n" 
		"\n";
	return 1;
}


int parse_AcmdA35(int argc, char **argv , ParaA35 * paraA35 )
{
	if (argc <=2 ) {print_AusageA35();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFa" )
		{
			if(i + 1 == argc) { LogLackArg(flag); return 0;}
			i++;
			paraA35->InFA=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) { LogLackArg(flag); return 0;}
			i++;
			paraA35->OutPut=argv[i];
		}
		else if (flag  ==  "GetIDList")
		{
			if(i + 1 == argc) { LogLackArg(flag); return 0;}
			i++;
			paraA35->GetIDList=argv[i];
		}
		else if (flag  ==  "GetID")
		{
			if(i + 1 == argc) { LogLackArg(flag); return 0;}
			i++;
			paraA35->getID=argv[i];
		}
		else if (flag  ==  "Pattern")
		{ 
			if(i + 1 == argc) { LogLackArg(flag); return 0;}
			i++;
			paraA35->pattern=argv[i];
		}
		else if (flag  ==  "UnPattern")
		{ 
			if(i + 1 == argc) { LogLackArg(flag); return 0;}
			i++;
			paraA35->unpattern=argv[i];
		}
		else if (flag  == "help")
		{
			print_AusageA35();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}

	if  ((paraA35->InFA).empty()||((paraA35->pattern).empty() && (paraA35->getID).empty() && (paraA35->unpattern).empty() &&  (paraA35->GetIDList).empty()  ) )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	if  (!(paraA35->OutPut).empty() )
	{        
		(paraA35->OutPut)=add_Asuffix(paraA35->OutPut);
	}
	return 1 ;

}


int FA_macth_main(int argc, char *argv[])
	// int main(int argc, char *argv[])
{
	ParaA35 * paraA35 = new ParaA35;
	if( parse_AcmdA35(argc, argv, paraA35 )==0)
	{
		delete  paraA35 ;
		return 0 ;
	}

	igzstream  IN ((paraA35->InFA).c_str(),ifstream::in);
	if(!IN.good())
	{
		cerr << "open InputFile error: "<<(paraA35->InFA)<<endl;
		delete  paraA35 ; return 0;
	}

	map <string,bool> IDHash ;
	if (!((paraA35->getID).empty()))
	{
		IDHash.insert(map <string,bool>:: value_type((paraA35->getID),true));
	}
	if (!((paraA35->GetIDList).empty()))
	{
		igzstream  INID ((paraA35->GetIDList).c_str(),ifstream::in);
		if(!INID.good())
		{
			cerr << "open InputFile error: "<<(paraA35->GetIDList)<<endl;
			delete  paraA35 ; return 0;             
		}
		while(!INID.eof())
		{
			string line,ID;
			getline(INID, line);
			if (line.empty())
			{
				continue;
			}
			istringstream isone (line,istringstream::in);
			isone>>ID;
			IDHash.insert(map <string,bool>:: value_type(ID,true));
		}
		INID.close();
	}

	if ( (paraA35->OutPut).empty() )
	{
		string tmp ;
		getline(IN, tmp, '>');
		while(!IN.eof())
		{
			string chr_line ,seq , chr_name;
			getline(IN, chr_line , '\n') ;
			getline(IN, seq , '>') ;
			istringstream isone (chr_line,istringstream::in);
			isone>>chr_name ;
			map <string, bool> :: iterator it ;
			if ((!IDHash.empty()))
			{
				it=IDHash.find(chr_name);
				if (it!=IDHash.end()) { cout<<">"<<chr_line<<endl<<seq;}
			}
			if ( (!(paraA35->pattern).empty()) && (chr_name.find((paraA35->pattern))!=string::npos) )
			{
				cout<<">"<<chr_line<<endl<<seq;
			}
			else if (  (!(paraA35->unpattern).empty()) && (chr_name.find((paraA35->unpattern))==string::npos) )
			{
				cout<<">"<<chr_line<<endl<<seq;
			}
		}
	}
	else
	{
		ogzstream OUT ((paraA35->OutPut).c_str());
		if (OUT.fail())
		{
			cerr << "open OUT File error: "<<(paraA35->OutPut)<<endl;
			delete  paraA35 ; return 0;
		}
		string tmp ;
		getline(IN, tmp, '>');
		while(!IN.eof())
		{
			string chr_line ,seq , chr_name;
			getline(IN, chr_line , '\n') ;
			getline(IN, seq , '>') ;
			istringstream isone (chr_line,istringstream::in);
			isone>>chr_name ;
			map <string, bool> :: iterator it ;
			if ((!IDHash.empty()))
			{
				it=IDHash.find(chr_name);
				if (it!=IDHash.end()){ OUT<<">"<<chr_line<<endl<<seq;}
			}
			if ((!(paraA35->pattern).empty()) && (chr_name.find((paraA35->pattern))!=string::npos) )
			{
				OUT<<">"<<chr_line<<endl<<seq;
			}
			else if ((!(paraA35->unpattern).empty()) && (chr_name.find((paraA35->unpattern))==string::npos) )
			{
				OUT<<">"<<chr_line<<endl<<seq;
			}
		}
		OUT.close();
	}
	delete paraA35 ;
	return 0;
}

///////// swimming in the sky and flying in the sea ////////////

