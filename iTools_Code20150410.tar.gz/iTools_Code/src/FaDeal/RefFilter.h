#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include <algorithm>
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"

//KSEQ_AINIT(gzFile, gzread)

using namespace std;
typedef long long  llong ;



class Para_FA03 {
	public:
		string InPut ;
		string OutPut ;
		int MinLen ;
		double NRatio ;
		Para_FA03()
		{
			InPut="";
			OutPut="";
			NRatio=0.5 ;
			MinLen=1000;
		}
};




int  usage_FA03()
{
	cout <<""
		"\n"
		"\tUsage: filter  -InPut <in.fa> -OutPut <out.fa>\n"
		"\n"
		"\t\t-InPut     <str>   Input fa for filter\n"
		"\t\t-OutPut    <str>   Output file\n"
		"\n"
		"\t\t-MinLen    <int>   The MinLength for Seq to pass[1000]\n"
		"\t\t-NRatio  <float>   The max ratio of miss N Length[0.5]\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_FA03(int argc, char **argv , Para_FA03 * para_FA03 )
{
	if (argc <=2 ) {usage_FA03();return 0;}


	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA03->InPut=argv[i];
		}
		else if (flag  ==  "MinLen")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA03->MinLen=atoi(argv[i]);
		}
		else if (flag  ==  "NRatio")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA03->NRatio=atof(argv[i]);
		}

		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA03->OutPut=argv[i];
		}
		else if (flag  == "help")
		{
			usage_FA03();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_FA03->InPut).empty() || (para_FA03->OutPut).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(para_FA03->OutPut)=add_Asuffix((para_FA03->OutPut)) ;
	return 1 ;
}




//int main(int argc, char *argv[])
int FA_Filter_main(int argc, char *argv[])
{
	Para_FA03 * para_FA03 = new Para_FA03;
	if( parse_Acmd_FA03(argc, argv, para_FA03 )==0)
	{
		delete  para_FA03 ;
		return 0;    
	}

	int linecut= FaCutLine ((para_FA03->InPut));

	ogzstream  OUT ((para_FA03->OutPut).c_str());
	if(!OUT.good())
	{
		cerr << "open OUT File error: "<<(para_FA03->OutPut)<<endl;
		delete  para_FA03 ;  return 0;
	}


	gzFile fp;
	kseq_t *seq;
	int l;
	fp = gzopen((para_FA03->InPut).c_str(), "r");
	seq = kseq_init(fp);

	while ((l = kseq_read(seq)) >= 0) 
	{
		string Ref=(seq->seq.s);
		llong seq_length=(seq->seq.l);
		if (seq_length<para_FA03->MinLen)
		{
			continue ;
		}
		llong N_length=0;
		size_t N_tail_position = 0 ;
		size_t N_head_position=Ref.find_first_of( "Nn", 0 );
		while( N_head_position != string::npos)
		{
			N_tail_position=Ref.find_first_of("AaCcTtGg",N_head_position+1);
			if (N_tail_position!= string::npos )
			{
				N_length+=(N_tail_position-N_head_position);
			}
			else
			{
				N_length+=(seq_length-N_head_position);
				break ;
			}
			N_head_position=Ref.find_first_of("Nn",N_tail_position);
		}
		if (((N_length*1.0)/seq_length)<(para_FA03->NRatio))
		{
			string ID=seq->name.s;
			if (seq->comment.l)
			{
				string tmp=seq->comment.s;
				ID=ID+"\t"+tmp;
			}
			Display( Ref,  ID , OUT ,linecut);
		}
	} 
	OUT.close();

	kseq_destroy(seq);
	gzclose(fp);
	delete para_FA03 ;
	return 0;

}

///////// swimming in the sky and flying in the sea ////////////
