
#ifndef FQ_ChangQ_H_
#define FQ_ChangQ_H_ 


#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include <algorithm> 

typedef long long  llong ;
#include "../include/gzstream/gzstream.h" 
#include "../ALL/comm.h" 
#include "../ALL/DataClass.h" 

using namespace std;

int  print_usageChangQ ()
{
	cout <<""
		"\n"
		"Usage:changQ  -InFq In.fq  -OutFq Out.fq\n"
		"\n"
		"\t\t-InFq     <str>   File name of InFq Input\n"
		"\t\t-OutFq    <str>   File name of OutFq output\n"
		"\n"
		"\t\t-Model    <int>   1/2; 1:Sangle2Solaxa 2: Solaxa2Sangle (-31) [1]\n"
		"\t\t-help             show this help\n" 
		"\n";
	return 1;
}
//
int parse_cmdChangQ(int argc, char **argv , In3str1v  * para )
{
	if (argc <=2  ) {print_usageChangQ();return 0;}

	int err_flag = 0;
	for(int i = 1; i < argc || err_flag; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFq" )
		{
			if(i + 1 == argc) { LogLackArg( flag ) ; return 0;}
			i++;
			para->InStr1=argv[i];
		}
		else if (flag  ==  "OutFq")
		{
			if(i + 1 == argc) { LogLackArg( flag ) ; return 0;}
			i++;
			para->InStr2=argv[i];
		}
		else if (flag  ==  "Model" )
		{
			if(i + 1 == argc) {  LogLackArg( flag ) ; return 0;}
			i++;
			int A=atoi(argv[i]);
			if (A!=1)
			{
				para->TF=false;
			}
		}
		else if (flag  == "help")
		{
			print_usageChangQ();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para->InStr2).empty() || (para->InStr1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(para->InStr2)=add_Asuffix(para->InStr2);
	return 1 ;
}






////////////////////////////



inline void trimA (  string & Quli )
{
	string::size_type i_end=Quli.size();
	for(string::size_type ix=0 ; ix<i_end ; ix++)
	{
		Quli[ix]=Quli[ix]+31;
	}

}

inline void trimB (  string & Quli )
{
	string::size_type i_end=Quli.size();
	for(string::size_type ix=0 ; ix<i_end ; ix++)
	{
		Quli[ix]=Quli[ix]-31;
	}
}


//programme entry
///////// swimming in the sky and flying in the sea ////////////
//int main(int argc, char **argv)
int FQ_ChangQ_main(int argc, char **argv)
{
	In3str1v * para = new In3str1v;        
	if (parse_cmdChangQ(argc, argv ,para )==0)
	{
		delete  para ; 
		return 1;
	}
	igzstream IN_1 ((para->InStr1).c_str(),ifstream::in); // ifstream  + gz 
	ogzstream OUT_1 ((para->InStr2).c_str());

	if(!IN_1.good())
	{
		cerr << "open IN File error: "<<para->InStr1<<endl;
		return 1;
	}
	if(!OUT_1.good())
	{
		cerr << "open OUT File error: "<<para->InStr2<<endl;
		return 1;
	} 
	if ((para->TF))
	{
		while(!IN_1.eof())
		{
			string ID_1 ,seq_1,temp_1,Quly_1 ;
			getline(IN_1,ID_1);
			getline(IN_1,seq_1);
			getline(IN_1,temp_1);
			getline(IN_1,Quly_1);

			//cerr<<ID_1<<"\t"<<seq_1<<"\t"<<temp_1<<"\t"<<Quly_1<<endl;
			trimA (Quly_1 );
			if (ID_1.length()<=0)  { continue  ; }
			OUT_1<<ID_1<<"\n"<<seq_1<<"\n"<<temp_1<<"\n"<<Quly_1<<endl;
		}
	}
	else
	{
		while(!IN_1.eof())
		{
			string ID_1 ,seq_1,temp_1,Quly_1 ;
			getline(IN_1,ID_1);
			getline(IN_1,seq_1);
			getline(IN_1,temp_1);
			getline(IN_1,Quly_1);
			trimB (Quly_1 );
			if (ID_1.length()<=0)  { continue  ; }
			OUT_1<<ID_1<<"\n"<<seq_1<<"\n"<<temp_1<<"\n"<<Quly_1<<endl;
		}
	}
	IN_1.close();
	OUT_1.close();
	return 1 ;
}

#endif  // FQ_Filter_H_


///////// swimming in the sky and flying in the sea ////////////
