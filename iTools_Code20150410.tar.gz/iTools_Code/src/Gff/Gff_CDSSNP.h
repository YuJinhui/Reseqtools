#ifndef RefGffCDS_H_
#define RefGffCDS_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"

//KSEQ_AINIT(gzFile, gzread)

using namespace std;
typedef long long  llong ;

int  Gff_CDSSNP_help()
{
	cout <<""
		"\n"
		"\tUsage: CDSSNP -Ref <in.fa> -Gff <in.gff> -SNP <in.raw>\n"
		"\n"
		"\t\t-Ref       <str>   Input Ref fa\n"
		"\t\t-Gff       <str>   Input Ref gff\n"
		"\t\t-SNP       <str>   Input SNP File\n"
		"\n"
		"\t\t-OutDir    <str>   Output Dir Path [./]\n"
		"\t\t-Format    <str>   SNP Input Form (cns/raw)[raw] \n"
		"\t\t-help              show this help\n"
		"\n";
	return 1;
}


char different_base ( char  ref , char  yh ,  map <char,string > SNP_back_Allele ,string & status )
{
	char base=yh;
	string A=& base ;
	status="Hom"; 

	if (A.find_first_of("AaTtCcGg")!=string::npos )
	{
	}
	else if(A.find_first_of("MRWSYK")!=string::npos)
	{
		string BB=SNP_back_Allele[yh];
		status = "Het-one";
		if (BB[0]==ref)
		{
			base=BB[1];
		}
		else if (BB[1]==ref)
		{
			base=BB[0];
		}
		else
		{
			status = "Het-two";
		}
	}
	else
	{
		cerr<<"different_base & hom_het unknown complex character, please check the snp data"<<endl;
	}
	return base;
}


void  convert_codon(string codon, string ref_codon, map <char,string > Allele, int phase ,vector <string> & NewCodon  )
{
	char base = (codon.substr(phase,1))[0];
	string AA=Allele[base];
	int length=AA.size();
	for (int i=0 ; i<length ; i++)
	{
		string new_codon = ref_codon;
		new_codon[phase]=AA[i];
		NewCodon.push_back(new_codon);
	}
}


int Gff_CDS_help01(int argc, char **argv , In3str1v * paraFA04 )
{
	if (argc <=2 ) {Gff_CDSSNP_help();return 0;}

	int err_Aflag = 0;

	for(int i = 1; i < argc || err_Aflag; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "Ref" )
		{
			if(i + 1 == argc) {cerr << "lack argument for '-Ref'" <<endl;err_Aflag = 1; return 0;}
			i++;
			paraFA04->InStr1=argv[i];
		}
		else if (flag  ==  "SNP")
		{
			if(i + 1 == argc) {cerr << "lack argument for '-SNP'" <<endl;err_Aflag = 1; return 0;}
			i++;
			paraFA04->InStr2=argv[i];
		}
		else if (flag  ==  "Gff")
		{
			if(i + 1 == argc) {cerr << "lack argument for '-Gff'" <<endl;err_Aflag = 1; return 0;}
			i++;
			paraFA04->InStr3=argv[i];
		}
		else if (flag  ==  "OutDir")
		{
			if(i + 1 == argc) {cerr << "lack argument for '-OutDir'" <<endl;err_Aflag = 1; return 0;}
			i++;
			string tmp=argv[i];
			(paraFA04->List).push_back(tmp) ;
		}
		else if (flag  ==  "Format")
		{
			if(i + 1 == argc) {cerr << "lack argument for '-Format'" <<endl;err_Aflag = 1; return 0;}
			i++;
			string tmp=argv[i];
			if (tmp == "cns")
			{
				paraFA04->TF=false;
			}
		}
		else if (flag  == "help")
		{
			Gff_CDSSNP_help();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA04->InStr1).empty() || (paraFA04->InStr2).empty() ||  (paraFA04->InStr3).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}

int Gff_CDSSNP_main(int argc, char *argv[])
{
	In3str1v *paraFA04 = new In3str1v;
	if( Gff_CDS_help01(argc, argv, paraFA04 )==0)
	{
		delete  paraFA04 ;
		return 0 ;
	}

	map <string,map <string ,bool> > GeneList;
	map <string,map <llong,llong> >  CDSList ;

	igzstream  MRG ((paraFA04->InStr3).c_str(),ifstream::in);
	if(!MRG.good())
	{
		cerr << "open InputFile error: "<<(paraFA04->InStr3)<<endl;
		delete  paraFA04 ; return 0;
	}

	igzstream SNP ((paraFA04->InStr2).c_str(),ifstream::in);
	if (SNP.fail())
	{
		cerr << "open SNP File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}
	int linecut= FaCutLine ((paraFA04->InStr1));

	string name = (paraFA04->InStr2).substr((paraFA04->InStr2).rfind('/')==string::npos ?((paraFA04->InStr2)).length():((paraFA04->InStr2)).rfind('/') + 1);
	name=replace_all(name,".gz","");

	while(!MRG.eof())
	{
		string  line ;
		getline(MRG,line);
		if (line.length()<=0)  { continue  ; }
		istringstream isone (line,istringstream::in);
		string chr , flag , CDS , ZhengFu ,geneID ;
		llong Start,End ;
		isone>>chr>>flag>>CDS ;
		if (CDS  != "CDS" )  { continue  ; }
		isone>>Start>>End>>flag>>ZhengFu>>flag>>geneID ;
		vector<string> inf;
		vector<string> Temp;
		split(geneID,inf,",;");
		split(inf[0],Temp,"=");
		string GeneID= Temp[Temp.size()-1] ;

		map <string,map <llong,llong> >  :: iterator it=CDSList.find(GeneID);

		if (it == CDSList.end())
		{
			bool A=false ;
			if (ZhengFu == "-")
			{
				A=true;
			}
			map <string,map <string ,bool> > :: iterator X =GeneList.find(chr);
			if (X==GeneList.end())
			{
				map <string,bool> First;
				First[GeneID]=A;
				GeneList.insert(map <string,map <string ,bool> > :: value_type(chr,First));
			}
			else
			{
				(X->second).insert(map <string ,bool>  :: value_type(GeneID ,A ));
			}
			map <llong,llong> DD;
			DD[Start]=End ;
			CDSList.insert(map <string,map <llong,llong> > ::value_type(GeneID,DD));
		}
		else
		{
			(it->second).insert(map <llong,llong>  :: value_type(Start,End)) ;
		}
	}

	MRG.close();

	map <string ,char > SNP_Allele ;
	SNP_Allele["AC"]='M'; SNP_Allele["CA"]='M'; SNP_Allele["GT"]='K'; SNP_Allele["TG"]='K';
	SNP_Allele["CT"]='Y'; SNP_Allele["TC"]='Y'; SNP_Allele["AG"]='R'; SNP_Allele["GA"]='R';
	SNP_Allele["AT"]='W'; SNP_Allele["TA"]='W'; SNP_Allele["CG"]='S'; SNP_Allele["GC"]='S';
	SNP_Allele["AA"]='A'; SNP_Allele["TT"]='T'; SNP_Allele["CC"]='C'; SNP_Allele["GG"]='G';
	map <char,string > SNP_back_Allele ;
	SNP_back_Allele['M']="AC";SNP_back_Allele['K']="GT";SNP_back_Allele['Y']="CT";
	SNP_back_Allele['R']="AG";SNP_back_Allele['W']="AT";SNP_back_Allele['S']="CG";
	SNP_back_Allele['C']="C";SNP_back_Allele['G']="G";SNP_back_Allele['T']="T";
	SNP_back_Allele['A']="A"; 
	SNP_back_Allele['V']="ACG"; SNP_back_Allele['H']="ACT";SNP_back_Allele['D']="AGT";
	SNP_back_Allele['B']="CGT";
	SNP_back_Allele['X']="ACGT"; SNP_back_Allele['N']="ACGT";

	map <string,string> CODE ;

	CODE["GCA"]="A"; CODE["GCC"]="A"; CODE["GCG"]="A"; CODE["GCT"]="A";  // #Alanine
	CODE["TGC"]="C"; CODE["TGT"]="C";                                    // #Cysteine
	CODE["GAC"]="D"; CODE["GAT"]="D";                                    // #AsparticAcid
	CODE["GAA"]="E"; CODE["GAG"]="E";                                    // #GlutamicAcid
	CODE["TTC"]="F"; CODE["TTT"]="F";                                    // #Phenylalanine
	CODE["GGA"]="G"; CODE["GGC"]="G"; CODE["GGG"]="G"; CODE["GGT"]="G";  // #Glycine
	CODE["CAC"]="H"; CODE["CAT"]="H";                                    // #Histidine
	CODE["ATA"]="I"; CODE["ATC"]="I"; CODE["ATT"]="I";                   // #Isoleucine
	CODE["AAA"]="K"; CODE["AAG"]="K";                                    // #Lysine
	CODE["CTA"]="L"; CODE["CTC"]="L"; CODE["CTG"]="L"; CODE["CTT"]="L";
	CODE["TTA"]="L"; CODE["TTG"]="L";                                    // #Leucine
	CODE["ATG"]="M";                                                     // #Methionine
	CODE["AAC"]="N"; CODE["AAT"]="N";                                    // #Asparagine
	CODE["CCA"]="P"; CODE["CCC"]="P"; CODE["CCG"]="P"; CODE["CCT"]="P";  // #Proline
	CODE["CAA"]="Q"; CODE["CAG"]="Q";                                    // #Glutamine
	CODE["CGA"]="R"; CODE["CGC"]="R"; CODE["CGG"]="R"; CODE["CGT"]="R";
	CODE["AGA"]="R"; CODE["AGG"]="R";                                    // #Arginine
	CODE["TCA"]="S"; CODE["TCC"]="S"; CODE["TCG"]="S"; CODE["TCT"]="S";
	CODE["AGC"]="S"; CODE["AGT"]="S";                                    // #Serine
	CODE["ACA"]="T"; CODE["ACC"]="T"; CODE["ACG"]="T"; CODE["ACT"]="T";  // #Threonine
	CODE["GTA"]="V"; CODE["GTC"]="V"; CODE["GTG"]="V"; CODE["GTT"]="V";  // #Valine
	CODE["TGG"]="W";                                                     // #Tryptophan
	CODE["TAC"]="Y"; CODE["TAT"]="Y";                                    // #Tyrosine
	CODE["TAA"]="U"; CODE["TAG"]="U"; CODE["TGA"]="U";                   // #Stop
	CODE["NNN"]="X";                                                     // #NA_NA



	map  <string,map <llong,pair <char,char> > > SNPList ;

	if (paraFA04->TF)
	{
		while(!SNP.eof())
		{
			string  line ;
			getline(SNP,line);
			if (line.length()<=0)  { continue  ; }
			istringstream isone (line,istringstream::in);
			string chr ,depth,cp ,allele1 , allele2 ,tmp1;
			llong position ; 
			char ref ,tmp2 ;
			isone>>chr>>position>>ref>>depth>>cp>>allele1>>allele2 ;
			tmp1=allele1+allele2;
			tmp2=SNP_Allele[tmp1];
			if (tmp2 == ref )
			{
				cerr<<"NoSNP at "<<chr<<"\t"<<position<<"\t"<<ref<<endl;
				continue ;
			}
			pair <int,int> temp ;
			temp=make_pair(ref,tmp2) ;
			map  <string,map <llong,pair <char,char> > >  :: iterator it=SNPList.find(chr);
			if (it != SNPList.end())
			{
				(it->second).insert(map <llong,pair <char,char> >  :: value_type(position,temp)) ;
			}
			else
			{
				map <llong,pair <char,char> > gene_cds_str;
				gene_cds_str[position]=temp;
				SNPList[chr]=gene_cds_str;
			}
		}

	}
	else
	{
		while(!SNP.eof())
		{
			string  line ;
			getline(SNP,line);
			if (line.length()<=0)  { continue  ; }
			istringstream isone (line,istringstream::in);
			string chr ;
			llong position ; 
			char ref ,tmp2 ;
			isone>>chr>>position>>ref>>tmp2 ;
			pair <int,int> temp ;

			if (tmp2 == ref )
			{
				cerr<<"NoSNP at "<<chr<<"\t"<<position<<"\t"<<ref<<endl;
				continue ;
			}

			temp=make_pair(ref,tmp2) ;
			map  <string,map <llong,pair <char,char> > >  :: iterator it=SNPList.find(chr);
			if (it != SNPList.end())
			{
				(it->second).insert(map <llong,pair <char,char> >  :: value_type(position,temp)) ;
			}
			else
			{
				map <llong,pair <char,char> > gene_cds_str;
				gene_cds_str[position]=temp;
				SNPList[chr]=gene_cds_str;
			}
		}
	}
	SNP.close();

	gzFile fp;
	kseq_t *seq;
	int l;

	fp = gzopen((paraFA04->InStr1).c_str(), "r");
	seq = kseq_init(fp);   
	string outpath="./";
	if (!(paraFA04->List).empty())
	{
		outpath=(paraFA04->List)[0];
	}

	string outInfo=outpath+"/"+name+".info.gz";
	string outCDS=outpath+"/"+name+".cds.gz";
	ogzstream OUT ((outInfo).c_str());
	ogzstream CDS ((outCDS).c_str());

	if((!OUT.good())  || (!CDS.good()) )
	{
		cerr << "open OUT File error: "<<(outInfo)<<"\t"<<outCDS<<endl;
		delete  paraFA04 ; return  0;
	}

	map <char ,char >  Complement;
	Complement['A']='T'; Complement['C']='G';  Complement['T']='A'; Complement['G']='C'; Complement['N']='N';
	Complement['a']='t'; Complement['c']='g';  Complement['t']='a'; Complement['g']='c'; Complement['n']='n';
	Complement['M']='K'; Complement['R']='Y';  Complement['W']='W'; Complement['S']='S'; Complement['Y']='R';
	Complement['K']='M';

	while ((l = kseq_read(seq)) >= 0)
	{
		string chr=seq->name.s ;
		map <string,map <string,bool> > :: iterator it=GeneList.find(chr);
		if (it != GeneList.end())
		{
			string Ref= seq->seq.s ;
			map <string,map <llong,pair <char,char> > > :: iterator snpit=SNPList.find(chr) ;
			map <string,bool> ::iterator  Y ;
			for(  Y=(it->second).begin() ; Y!= (it->second).end(); Y++ )
			{
				bool TF=Y->second;
				map  <string,map <llong,llong> > :: iterator mCDS=CDSList.find(Y->first);

				string gene_cds_str , ref_cds_str , axt_cds_str ;
				int mRNA_pos=1 , gene_cds_len=0 ;

				map <llong,llong> :: iterator PUPU ;
				for(  PUPU=(mCDS->second).begin() ; PUPU!= (mCDS->second).end(); PUPU++ )
				{
					llong START=(PUPU->first)-1 ;
					int Leng=(PUPU->second)-START;
					gene_cds_str=gene_cds_str+Ref.substr(START,Leng) ;
				}
				char strand='+';
				gene_cds_len=gene_cds_str.length();
				if (TF)
				{
					reverse(gene_cds_str.begin(), gene_cds_str.end());
					for (int i=0 ; i<gene_cds_len ; i++)
					{
						gene_cds_str[i]=Complement[gene_cds_str[i]];
					}
					strand='-';
				}

				ref_cds_str = gene_cds_str;
				axt_cds_str = gene_cds_str;
				string ID=(Y->first)+"\t"+(it->first) ;
				Display( gene_cds_str , ID ,  CDS ,linecut  );

				for(  PUPU=(mCDS->second).begin() ; PUPU!= (mCDS->second).end(); PUPU++ )
				{
					for (llong kk=(PUPU->first) ; kk<=(PUPU->second)  ; kk++ )
					{
						map <llong,pair <char,char> > :: iterator SNPYY=(snpit->second).find(kk) ;
						//map <string,map <llong,pair <char,char> > > :: iterator snpit=SNPList.find(chr) ;
						if ( SNPYY !=(snpit->second).end())
						{
							char ref_base_1 = (Ref.substr(kk-1,1))[0];
							if ( ref_base_1 != (SNPYY->second).first )
							{
								cerr<<"same thing wrong "<<chr<<" "<<kk<<" "<<ref_base_1<<" "<<(SNPYY->second).first<<endl;
							}
							char SNP_base_1=(SNPYY->second).second ;
							char SNP_base_2=Complement[SNP_base_1];
							char ref_base_2=Complement[ref_base_1];
							int this_mRNA_pos=mRNA_pos;
							int this_yh_base=SNP_base_1 ;
							int this_ref_base=ref_base_1 ;
							if (TF)
							{
								this_mRNA_pos=gene_cds_len - mRNA_pos + 1;
								this_yh_base=SNP_base_2;
								this_ref_base=ref_base_2; 
							}
							gene_cds_str[this_mRNA_pos-1]=this_yh_base;
							string snp_status ;
							axt_cds_str[this_mRNA_pos-1]=different_base(this_ref_base,this_yh_base,SNP_back_Allele,  snp_status );
							int phase_num = (this_mRNA_pos-1)%3;
							int codon_num = (this_mRNA_pos-1-phase_num)/3 + 1;

							OUT<<chr<<"\t"<<kk<<"\t"<<ref_base_1<<"<->"<<SNP_base_1<<"\t"<<snp_status<<"\t"<<strand<<"\tGene\t";
							string ref_codon =ref_cds_str.substr(this_mRNA_pos-phase_num-1,3);
							string yh_codon =gene_cds_str.substr(this_mRNA_pos-phase_num-1,3);
							if(yh_codon.find_first_of("Nn")!=string::npos)
							{
								cerr<<yh_codon<<" has N, please check"<<chr<<"\t"<<kk<<"\t"<<ref_base_1<<endl;
							}
							string yh_codon1=yh_codon ,yh_codon2=yh_codon ;
							if ( snp_status.find("Het")!=string::npos)
							{
								vector <string>  NewCodon ;
								//                                cerr<<yh_codon1<<"\t"<<yh_codon2<<"\t";
								convert_codon(yh_codon,ref_codon, SNP_back_Allele,phase_num, NewCodon );
								yh_codon1=NewCodon[0];
								yh_codon2=NewCodon[1];
								//                              cerr<<yh_codon1<<"\t"<<yh_codon2<<endl;
							}

							int  synonymous=0,nonsynonymous = 0;
							OUT<<Y->first<<"\tCDS\t"<<this_mRNA_pos<<":"<<phase_num<<"\t";
							string codon_mutate_str, aa_mutate_str ;
							if (ref_codon != yh_codon1)
							{
								if (CODE[ref_codon] ==  CODE[yh_codon1])
								{
									synonymous += 1;
								}
								else
								{
									nonsynonymous += 1;
								}
								codon_mutate_str += ref_codon+"<->"+yh_codon1+";";
								aa_mutate_str += CODE[ref_codon]+"<->"+CODE[yh_codon1]+";";
							}
							if (ref_codon !=  yh_codon2) 
							{
								if (CODE[ref_codon] == CODE[yh_codon2])
								{
									synonymous += 1;
								}
								else
								{
									nonsynonymous += 1;
								}
								if (yh_codon2 != yh_codon1 )
								{
									codon_mutate_str += ref_codon+"<->"+yh_codon2+";";
									aa_mutate_str += CODE[ref_codon]+"<->"+CODE[yh_codon2]+";";
								}
							}
							OUT<<codon_mutate_str<<"\t"<<aa_mutate_str<<"\t"<<synonymous<<"\t"<<nonsynonymous<<endl;
						}

						mRNA_pos++;
					}

				}

			}
		}
	}
	OUT.close();
	CDS.close();
	kseq_destroy(seq);
	gzclose(fp);
	delete paraFA04 ;
	return 0;
}
#endif // RefGffCDS_H_ //
///////// swimming in the sky and flying in the sea ////////////

