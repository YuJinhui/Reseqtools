#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <ext/hash_map>
#include "../ALL/comm.h"
#include "../ALL/kseq.h"
#include "../ALL/DataClass.h"
#include "../Soap/xam2soap/TSamCtrl.h"
#include "../Soap/xam2soap/Ttools.h"
#include "../include/gzstream/gzstream.h" 

using namespace std;
using namespace __gnu_cxx;

///////////////////
int  print_Other02()
{
	cout <<""
		"\n"
		"\tUsage: split -ChrList <Ref.fa.chrlist> -InList <soap.list>\n"
		"\n"
		"\t\t-ChrList   <str>   Input the chrList\n"
		"\t\t-InFile    <str>   [Repeat] Input sam,bam file\n"
		"\t\t-InList    <str>   Input sam,bam file list\n"
		"\t\t\n"
		"\t\t-OutDir    <str>   Output Dir for split SubFile[./]\n"
		"\t\t-Row       <int>   the row Num of the chr name[8]\n"
		"\t\t-help              show this help\n"
		"\n";
	return 1;
}

int parse_Other02(int argc, char **argv , In3str1v * para_Other02 )
{
	if (argc <=2 ) {print_Other02();return 0;}


	for(int i = 1; i < argc; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "ChrList")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_Other02->InStr1=argv[i];
		}
		else if (flag  ==  "InFile")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			string tmp=argv[i];
			(para_Other02->List).push_back(tmp);
		}
		else if (flag  ==  "Row")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			(para_Other02->InInt)=atoi(argv[i]);
		}        
		else if (flag  ==  "OutDir")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			(para_Other02->InStr2)=argv[i];
		}
		else if (flag  ==  "InList" )
		{
			if(i + 1 == argc) { LogLackArg(flag);return 0; }
			i++;
			string tmp=argv[i];
			ReadList (tmp  , (para_Other02->List) );
		}
		else if (flag  == "help")
		{
			print_Other02();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}

	if  (((para_Other02->List).size()<1) ||  (para_Other02->InStr1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}


//////////////////
int Other_split_main(int argc,char *argv[] )
{

	In3str1v  * para_Other02 = new In3str1v ;
	(para_Other02->InStr2)="./";
	(para_Other02->InInt)=8;
	if (parse_Other02( argc, argv, para_Other02)==0)
	{
		delete para_Other02 ;
		return 0;
	}

	string  OutDir=(para_Other02->InStr2);
	OutDir+="/";
	string ChrList=(para_Other02->InStr1);
	vector <string> File ;
	map <string,int>  Soap2Int ;

	igzstream IN (ChrList.c_str(),ifstream::in); // igzstream     
	if(!IN.good())
	{
		cerr << "open InputFile error: "<<ChrList<<endl;
		return 1;
	}
	int  chr_count=0 ;
	////////////////////////swimming in the sea & flying in the sky //////////////////   
	while(!IN.eof())
	{
		string  line ,chr ;
		getline(IN,line);
		if (line.length()<=0)  { continue  ; }
		istringstream isone (line,istringstream::in);
		isone>>chr ;
		Soap2Int[chr]=chr_count;
		line=OutDir+chr+".gz";
		File.push_back(line);
		chr_count++;
	}
	IN.close();


	int File_count=File.size();
	if (File_count>168)
	{
		cerr<<"Waining :chr num too much"<<endl ;
	}
	ogzstream *Soap2Chr = new ogzstream[File_count] ;

	for (int i=0; i<File_count ; i++)
	{
		Soap2Chr[i].open(File[i].c_str()) ;
		if  (!Soap2Chr[i].good())
		{
			cerr<<"Can't open follow output:\n"<<File[i]<<endl;
		}
	}

	int Soap_Stat_count=(para_Other02->List).size();
	for (int i=0; i<Soap_Stat_count ; i++)
	{
		string sampath=(para_Other02->List)[i]; 

		igzstream INSOAP (sampath.c_str(),ifstream::in); // igzstream     
		if (INSOAP.fail())    
		{
			cerr<<"can't open the file\t"<<sampath<<endl;
		}
		while(!INSOAP.eof())
		{
			string line;
			getline(IN,line);
			if (line.length()<=0)  { continue ; }
			istringstream isone (line,istringstream::in);
			string tmp, chr ;
			for (int kk=1 ; kk<(para_Other02->InInt) ; kk++ )
			{
				isone>>tmp;
			}
			isone>>chr;
			Soap2Chr[Soap2Int[chr]]<<line<<endl;
		}
		INSOAP.close();
		INSOAP.clear();
	}

	for (int i=0; i<File_count ; i++)
	{
		Soap2Chr[i].close() ;
	}

	//////////swimming in the sky and flying in the sea ///////////
	delete para_Other02 ;
	return 0 ;
}



////////////////////////swimming in the sea & flying in the sky //////////////////


