#ifndef LDDecay_H_
#define LDDecay_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../CNSTool/filter_genotype.h"

using namespace std;
typedef long long  llong ;

int  Gff_LDdecaySNP_help()
{
	cout <<""
		"\n"
		"\tUsage: LDDecay -InSNP  <in.genotype>  -OutStat <out.stat>\n"
		"\n"
		"\t\t-InSNP       <str>     Input SNP genotype File \n"
		"\t\t-OutStat     <str>     OutPut Dist ~ r^2 File\n"
		"\n"
		"\t\t-MaxDist     <int>     Max Distance (kb) between two SNP [500]\n"
		"\t\t-MAF         <float>   Min minor allele frequency filter [0.005]\n"
		"\t\t-Het         <float>   Max ratio of het allele filter [0.88]\n"
		"\t\t-Miss        <float>   Max ratio of miss allele filter [0.25]\n"
		"\t\t-OutPairLD             OutPut the pair SNP LD info\n"
		"\t\t-OutBinDraw  <int>     OutPut Bin for merge SNP pairs for mean r^2 [1]\n"
		"\t\t-OutFilterSNP          OutPut the final SNP for calculate\n"
		"\t\t\n"
		"\t\t-help             show this help\n"
		"\n";
	return 1;
}

int Gff_LDdecay_help01(int argc, char **argv , In3str1v * paraFA04, Para_18 * para_18 )
{
	if (argc <=2 ) {Gff_LDdecaySNP_help();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InSNP")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr1=argv[i];
		}
		else if (flag  ==  "OutStat")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr2=argv[i];
		}
		else if (flag  == "Het" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_18->Het=atof(argv[i]);
		}
		else if (flag == "MAF" )
		{
			if(i + 1== argc) {LogLackArg(flag);return 0;}
			i++;
			para_18->MAF=atof(argv[i]);
		}
		else if (flag == "Miss" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_18->Miss=atof(argv[i]);
		}
		else if (flag == "BinDraw" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_18->Cut3base=atoi(argv[i]);
		}

		else if (flag == "MaxDist" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			paraFA04->InInt=atoi(argv[i]);
		}
		else if (flag == "OutPairLD")
		{
			paraFA04->TF=false;
		}
		else if (flag == "OutFilterSNP")
		{
			paraFA04->TF2=false;
		}
		else if (flag == "help")
		{
			Gff_LDdecaySNP_help();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA04->InStr1).empty() || (paraFA04->InStr2).empty()  )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}

int GetBestBase ( string Genotype, map <string ,char > SNP_Allele , map <string,string > SNP_back_Allele ,  vector <char> &  Base_list  )
{
	vector<string>  Base1 ;
	split(Genotype, Base1," \t");
	map <char,int > Count ;
	int Asize=Base1.size();
	for (int ii=0 ;ii<Asize ; ii++)
	{
		string A_tmp=SNP_back_Allele[Base1[ii]];
		Count[A_tmp[0]]++;
		Count[A_tmp[1]]++;
	}
	char best_base='N';
	char sed_base='N';
	int Max=0;
	int SeD=0;
	map <char,int>  :: iterator it=Count.begin();
	for ( ; it!=Count.end(); it++ )
	{	
		if ( (it->first ) == 'N' )
		{
			continue ;
		}
		else if ((it->second)  > Max )
		{
			SeD=Max;
			sed_base=best_base;
			Max=(it->second);
			best_base=it->first;
		}
		else if ( (it->second)  >= SeD )
		{
			SeD=(it->second);
			sed_base=it->first;
		}
	}
	map <string ,string > Allele2double;
	Allele2double["-"]="NN";
	Allele2double["N"]="NN";
	Allele2double["n"]="NN";
	string tmp="";
	string A_base=best_base+tmp;
	string B_base=sed_base+tmp;
	string Het_base=A_base+B_base;
	string C_base=SNP_Allele[Het_base]+tmp;

	Allele2double[A_base]=(A_base+A_base);
	Allele2double[B_base]=(B_base+B_base);
	Allele2double[C_base]=Het_base;
	Base_list.push_back(best_base);
	Base_list.push_back(sed_base);
	for (int ii=0 ;ii<Asize ; ii++)
	{
		string A_tmp=Allele2double[Base1[ii]];
		if (A_tmp=="") 		{	A_tmp=Het_base;	}
		Base_list.push_back(A_tmp[0]);
		Base_list.push_back(A_tmp[1]);
	}
	return 1;
}

int cal_RR_D( vector<char>  Base1  , vector<char>  Base2   , double & D ,double & RR )
{
	int Asize=Base1.size();
	map <string,int > Count ;
	string tmp="";
	for (int ii=2 ;ii<Asize ; ii++)
	{
		if ( (Base1[ii] == 'N')  ||  (Base2[ii] == 'N'))
		{
			continue ;
		}
		string A_tmp=tmp+(Base1[ii])+(Base2[ii]);
		Count[A_tmp]++;
	}
	string  A1B1_base=tmp+Base1[0]+Base2[0];
	int     A1B1_count=0;
	double  A1B1_pro=0.0;
	map <string,int>  :: iterator it=Count.find(A1B1_base);
	if (it!=Count.end())
	{
		A1B1_count=it->second;
	}

	string  A1B2_base=tmp+Base1[0]+Base2[1];
	int     A1B2_count=0;
	double  A1B2_pro=0.0;

	it=Count.find(A1B2_base);
	if (it!=Count.end())
	{
		A1B2_count=it->second;
	}

	string  A2B2_base=tmp+Base1[1]+Base2[1];
	int     A2B2_count=0;
	double  A2B2_pro=0.0;

	it=Count.find(A2B2_base);
	if (it!=Count.end())
	{
		A2B2_count=it->second;
	}

	string  A2B1_base=tmp+Base1[1]+Base2[0];
	int     A2B1_count=0;
	double  A2B1_pro=0.0;
	it=Count.find(A2B1_base);
	if (it!=Count.end())
	{
		A2B1_count=it->second;
	}

	if ( A2B2_count==0  &&    A2B1_count==0)
	{
		return 0 ;
	}
	if ( A2B2_count==0  &&    A1B2_count==0)
	{
		return 0 ;
	}

	int ALL_count=A1B1_count+A1B2_count+A2B2_count+A2B1_count;
	A1B1_pro=(A1B1_count*1.0)/ALL_count;
	A1B2_pro=(A1B2_count*1.0)/ALL_count;
	A2B1_pro=(A2B1_count*1.0)/ALL_count;
	A2B2_pro=1-A1B1_pro-A1B2_pro-A2B1_pro ;

	double A1_pro=A1B1_pro+A1B2_pro;
	double A2_pro=A2B1_pro+A2B2_pro;
	double B1_pro=A1B1_pro+A2B1_pro;
	double B2_pro=A1B2_pro+A2B2_pro;

	double p1q1=(A1_pro*B1_pro); 
	double D_A=A1B1_pro-p1q1;
	double Cal_A , Cal_B ;
	if (D_A==0)
	{
		D=0; RR=0;  return 1;
	}
	else if (D_A>0)
	{
		Cal_A=A1_pro*B2_pro;
		Cal_B=A2_pro*B1_pro;
	}
	else if (D_A<0)
	{
		Cal_A=p1q1;
		Cal_B=A2_pro*B2_pro;
	}
	else
	{
		D=0; RR=0;
		return 1;
	}
	double D_max=min(Cal_A,Cal_B);

	RR=(D_A/Cal_A)*(D_A/Cal_B);
	D_A=abs(D_A);
	D=D_A/D_max;
	return 1;
}

int LDdecaySNP_main(int argc, char *argv[])
	//int main(int argc, char *argv[])
{
	In3str1v *paraFA04 = new In3str1v;
	Para_18 * para_18 = new Para_18 ;
	paraFA04->InInt=500;
	para_18->MAF=0.005;
	para_18->Miss=0.25;
	para_18->Cut3base=1;
	if ((Gff_LDdecay_help01(argc, argv, paraFA04, para_18)==0))
	{
		delete paraFA04 ;
		delete para_18 ;
		return 0 ;
	}

	string OUT_TMP=(paraFA04->InStr2)+".filter.gz";
	char * A = const_cast<char*>((paraFA04->InStr1).c_str());
	char * B = const_cast<char*>((OUT_TMP).c_str());
	stringstream   sstrmC ;
	sstrmC  <<  (para_18->MAF);
	string  C=sstrmC.str();
	char * MAF = const_cast<char*>((C).c_str());	

	stringstream   sstrmA ;
	sstrmA  <<  (para_18->Miss);
	string  D=sstrmA.str();
	char * Miss = const_cast<char*>((D).c_str());	

	stringstream   sstrmB ;
	sstrmB  <<  (para_18->Het);
	string	 E=sstrmB.str();
	char * Het = const_cast<char*>((E).c_str());	

	char * TmpFF[12]={"FilterGeno", "-InPut", A , "-OutPut" , B , "-Cut3base", "-Miss", Miss, "-MAF", MAF ,"-Het", Het };
	Filter_genotype_main( 12 ,  TmpFF );

	llong MaxDis=(paraFA04->InInt)*1000;
	map <string ,char > SNP_Allele ;
	SNP_Allele["AC"]='M'; SNP_Allele["CA"]='M'; SNP_Allele["GT"]='K'; SNP_Allele["TG"]='K';
	SNP_Allele["CT"]='Y'; SNP_Allele["TC"]='Y'; SNP_Allele["AG"]='R'; SNP_Allele["GA"]='R';
	SNP_Allele["AT"]='W'; SNP_Allele["TA"]='W'; SNP_Allele["CG"]='S'; SNP_Allele["GC"]='S';
	SNP_Allele["AA"]='A'; SNP_Allele["TT"]='T'; SNP_Allele["CC"]='C'; SNP_Allele["GG"]='G';

	map <string,string > SNP_back_Allele ;
	SNP_back_Allele["M"]="AC";SNP_back_Allele["K"]="GT";SNP_back_Allele["Y"]="CT";
	SNP_back_Allele["R"]="AG";SNP_back_Allele["W"]="AT";SNP_back_Allele["S"]="CG";
	SNP_back_Allele["C"]="CC";SNP_back_Allele["G"]="GG";SNP_back_Allele["T"]="TT";
	SNP_back_Allele["A"]="AA";
	SNP_back_Allele["-"]="NN"; SNP_back_Allele["N"]="NN";

	igzstream SNP (OUT_TMP.c_str(),ifstream::in);
	if (SNP.fail())
	{
		cerr << "open SNP File error: "<<OUT_TMP<<endl;
		delete para_18 ;
		delete  paraFA04 ; return  0;
	}

	string Stat=(paraFA04->InStr2)+".stat.gz";
	ogzstream OUT ((Stat).c_str());

	if((!OUT.good()) )
	{
		cerr << "open OUT File error: "<<(paraFA04->InStr2)<<endl;
		delete para_18 ;
		delete  paraFA04 ; return  0;
	}

	map <string,map <llong, vector <char> > >  SNPList ;
	//////// swimming in the sea & flying in the sky /////////////

	int Flag_for_pro=0;
	while(!SNP.eof())
	{
		string  line ;
		getline(SNP,line);
		if (line.length()<=0 || line[0] == '#' )  { continue  ; }
		string GeneID  ;
		llong Site ;
		vector<string> inf ;
		split(line,inf,"\t");

		istringstream isone (inf[1],istringstream::in);
		isone>> Site ;
		GeneID=inf[0];
		vector<char>  genotype ;
		GetBestBase ( inf[2] , SNP_Allele , SNP_back_Allele , genotype );
		map <string,map <llong, vector <char> > >  :: iterator it=SNPList.find(GeneID);
		if (it == SNPList.end())
		{
			map <llong, vector <char> > DD;
			DD[Site]=genotype;
			SNPList.insert(map <string,map <llong,vector <char> > > ::value_type(GeneID,DD));
			Flag_for_pro++;
		}
		else
		{
			(it->second).insert(map <llong, vector <char> >  :: value_type(Site,genotype)) ;
			Flag_for_pro++;
		}
	}

	SNP.close();

	if (paraFA04->TF2)
	{
		string  MV="rm -rf  "+OUT_TMP;
		system(MV.c_str()) ;
	}

	map <string,map<llong, vector <char>  > > :: iterator key1_it ;
	double  RR=1.0;
	double  DD=0;
	int bin_count=int(Flag_for_pro/100)+1;
	int Flag=1;
	int Flag_Now=0;


	map <llong ,pair <int,pair<double,double> > > All_Stat;
	map <llong ,pair <int,pair<double,double> > > :: iterator key_stat;
	cerr<<"##begin pair R^2 cal. after filter Remain SNP Number :\t"<<Flag_for_pro<<"\n#\% number bin is\t"<<bin_count<<endl;

	if (paraFA04->TF)
	{
		for (key1_it=SNPList.begin(); key1_it!=SNPList.end() ;key1_it++)
		{
			map<llong, vector <char> >  :: iterator key2 ;
			map<llong, vector <char> >  :: iterator key2_se  ;
			for( key2=(key1_it->second).begin(); key2!=(key1_it->second).end(); key2++)
			{
				key2_se=key2 ;  key2_se++ ; 
				Flag_Now++;
				if ((Flag_Now/bin_count)>Flag)
				{
					cerr<<Flag<<"%...\t"<<key1_it->first<<"\t"<<(key2->first)<<endl;
					Flag++;
				}
				for(   ; key2_se!=(key1_it->second).end(); key2_se++ )
				{
					llong Dis=(key2_se->first)-(key2->first);

					if ( Dis> MaxDis )
					{
						break ;
					}
					else
					{
						if(	cal_RR_D( key2->second , key2_se->second  , DD , RR ) ==1)
						{
							key_stat=All_Stat.find(Dis);
							if ( key_stat!=All_Stat.end())
							{
								(key_stat->second).first++;
								((key_stat->second).second).first+=DD;
								((key_stat->second).second).second+=RR;
							}
							else
							{
								pair<double,double> A;
								pair <int,pair<double,double> > B;
								A=make_pair(DD,RR);
								B=make_pair(1,A);
								All_Stat.insert(map <llong , pair <int,pair<double,double> > > :: value_type(Dis,B));
							}
						}
					}
				}
			}
		}
	}
	else
	{
		string LDOUT_file=(paraFA04->InStr2)+".LD.gz";
		ogzstream LDOUT (LDOUT_file.c_str());
		LDOUT<<"#chr\tSite1\tSite2\tD'\tr^2\tDist"<<endl;
		for (key1_it=SNPList.begin(); key1_it!=SNPList.end() ;key1_it++)
		{
			map<llong, vector <char> >  :: iterator key2 ;
			map<llong, vector <char> >  :: iterator key2_se  ;
			for( key2=(key1_it->second).begin(); key2!=(key1_it->second).end(); key2++ )
			{
				key2_se=key2 ;  key2_se++ ; 
				Flag_Now++;
				if ((Flag_Now/bin_count)>Flag)
				{
					cerr<<Flag<<"%...\t"<<key1_it->first<<"\t"<<(key2->first)<<endl;
					Flag++;
				}
				for(   ; key2_se!=(key1_it->second).end(); key2_se++ )
				{
					llong Dis=(key2_se->first)-(key2->first);
					if ( Dis> MaxDis )
					{
						break ;
					}
					else
					{
						if(	cal_RR_D( key2->second , key2_se->second  , DD , RR ) ==1)
						{
							LDOUT<<key1_it->first<<"\t"<<key2->first<<"\t"<<(key2_se->first)<<setprecision(4)<<setiosflags(ios::right)<<setiosflags(ios::fixed)<<"\t"<<DD<<"\t"<<RR<<"\t"<<Dis<<endl;
							key_stat=All_Stat.find(Dis);
							if ( key_stat!=All_Stat.end())
							{
								(key_stat->second).first++;
								((key_stat->second).second).first+=DD;
								((key_stat->second).second).second+=RR;
							}
							else
							{
								pair<double,double> A;
								pair <int,pair<double,double> > B;
								A=make_pair(DD,RR);
								B=make_pair(1,A);
								All_Stat.insert(map <llong , pair <int,pair<double,double> > > :: value_type(Dis,B));
							}
						}
					}
				}
			}
		}
		LDOUT.close();
	}

	cerr<<Flag<<"%......-->100%.......\t\tALL done"<<endl;
	OUT<<"#Dist\tMean_r^2\tMean_D'\tSum_r^2\tSum_D'\tNumberPairs\n";
	key_stat=All_Stat.begin();
	for (  ; key_stat!=All_Stat.end() ; key_stat++)
	{
		llong Dist=key_stat->first;
		int count=(key_stat->second).first;
		double SumRR=((key_stat->second).second).second;
		double SumD=((key_stat->second).second).first;

		double MeanRR=SumRR/count;
		double MeanD=SumD/count;
		OUT<<Dist<<setprecision(4)<<setiosflags(ios::right)<<setiosflags(ios::fixed)<<"\t"<<MeanRR<<"\t"<<MeanD<<"\t"<<SumRR<<"\t"<<SumD<<"\t"<<count<<endl;
	}

	OUT.close();


	if (  para_18->Cut3base >1 )
	{
		string StatBin=(paraFA04->InStr2)+".stat.bin.gz";
		ogzstream OUTBIN ((StatBin).c_str());
		map <llong ,pair <int,pair<double,double> > > All_BinStat;
		map <llong ,pair <int,pair<double,double> > > :: iterator key_binstat;
		key_stat=All_Stat.begin();
		for (  ; key_stat!=All_Stat.end() ; key_stat++)
		{
			llong Dist=key_stat->first;
			llong Dist_bin=(llong(Dist/(para_18->Cut3base))+1)*(para_18->Cut3base);
			key_binstat=All_BinStat.find(Dist_bin);
			if ( key_binstat!=All_BinStat.end())
			{
				(key_binstat->second).first+=(key_stat->second).first;
				((key_binstat->second).second).first+=((key_stat->second).second).first;
				((key_binstat->second).second).second+=((key_stat->second).second).second;
			}
			else
			{
				pair<double,double> A;
				pair <int,pair<double,double> > B;

				A=make_pair(((key_stat->second).second).first , ((key_stat->second).second).second );
				B=make_pair((key_stat->second).first,A);
				All_BinStat.insert(map <llong , pair <int,pair<double,double> > > :: value_type(Dist_bin,B));
			}
		}


		OUTBIN<<"#Dist\tMean_r^2\tMean_D'\tSum_r^2\tSum_D'\tNumberPairs\n";
		key_stat=All_BinStat.begin();
		for (  ; key_stat!=All_BinStat.end() ; key_stat++)
		{
			llong Dist=key_stat->first;
			int count=(key_stat->second).first;
			double SumRR=((key_stat->second).second).second;
			double SumD=((key_stat->second).second).first;

			double MeanRR=SumRR/count;
			double MeanD=SumD/count;
			OUTBIN<<Dist<<setprecision(4)<<setiosflags(ios::right)<<setiosflags(ios::fixed)<<"\t"<<MeanRR<<"\t"<<MeanD<<"\t"<<SumRR<<"\t"<<SumD<<"\t"<<count<<endl;
		}


		OUTBIN.close();
	}

	delete para_18 ;
	delete paraFA04 ;
	return 0;
}
#endif // LDDecay_H_ //
///////// swimming in the sky and flying in the sea ////////////

