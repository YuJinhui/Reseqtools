#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include "HelpTemp.h"

#ifndef Less_H_
#define Less_H_

using namespace std;

//programme entry
///////// swimming in the sky and flying in the sea ////////////
int Other_less_main(int argc, char **argv)
{
	if (argc<2)
	{
		cout <<""
			"\n"
			"\tUsage: less\tfile.txt\n"
			"\n";
		return  0;
	}
	char * ssTmp[3]={argv[0], "less", argv[1]};
	help_main(3 , ssTmp ) ;
	return 0;
}
#endif 
///////// swimming in the sky and flying in the sea ////////////
